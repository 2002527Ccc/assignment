module Inevitable

@addField(AttackData)
public let ineSilentStunCandidate: Bool;

@addField(AttackData)
public let ineSilentStunApplied: Bool;

@addField(NPCPuppet)
public let ineVulnerableUntil: Float;

public abstract class INE_Combat {
  public final static func Now(target: ref<NPCPuppet>) -> Float {
    return EngineTime.ToFloat(GameInstance.GetSimTime(target.GetGame()));
  }

  public final static func DirectPlayerWeaponHit(hit: ref<gameHitEvent>) -> Bool {
    let attackType: gamedataAttackType;
    if !IsDefined(hit) || !IsDefined(hit.attackData) || hit.projectionPipeline {
      return false;
    };
    if !IsDefined(hit.attackData.GetInstigator()) || !hit.attackData.GetInstigator().IsPlayer() || !IsDefined(hit.attackData.GetWeapon()) {
      return false;
    };
    if hit.attackData.HasFlag(hitFlag.DealNoDamage) || hit.attackData.HasFlag(hitFlag.DamageNullified) {
      return false;
    };
    attackType = hit.attackData.GetAttackType();
    // Exclude hacks, damage-over-time, area effects and scripted Direct attacks.
    return Equals(attackType, gamedataAttackType.Ranged) || Equals(attackType, gamedataAttackType.Thrown) || AttackData.IsMelee(attackType);
  }

  public final static func InevitableHit(hit: ref<gameHitEvent>) -> Bool {
    let attackType: gamedataAttackType;
    if !INE_Combat.DirectPlayerWeaponHit(hit) || ItemID.GetTDBID(hit.attackData.GetWeapon().GetItemID()) != t"Items.Inevitable" {
      return false;
    };
    attackType = hit.attackData.GetAttackType();
    return Equals(attackType, gamedataAttackType.Thrown) || AttackData.IsMelee(attackType);
  }

  public final static func HeadHit(hit: ref<gameHitEvent>) -> Bool {
    let data: ref<HitShapeUserDataBase>;
    if hit.attackData.HasFlag(hitFlag.Headshot) {
      return true;
    };
    // Native Headshot flags exclude melee. Inspect its hit shape as well.
    if ArraySize(hit.hitRepresentationResult.hitShapes) > 0 {
      data = DamageSystemHelper.GetHitShapeUserDataBase(hit.hitRepresentationResult.hitShapes[0]);
      return IsDefined(data) && HitShapeUserDataBase.IsHitReactionZoneHead(data);
    };
    return false;
  }

  public final static func SilentControlHit(hit: ref<gameHitEvent>) -> Bool {
    let target: ref<NPCPuppet>;
    if !INE_Combat.InevitableHit(hit) || !hit.attackData.ineSilentStunApplied {
      return false;
    };
    target = hit.target as NPCPuppet;
    return IsDefined(target) && !target.IsDead() && !target.IsAboutToDie() && StatusEffectSystem.ObjectHasStatusEffect(target, t"BaseStatusEffect.Stun");
  }

  public final static func AfterHit(hit: ref<gameHitEvent>, hadNativeStun: Bool) -> Void {
    let target: ref<NPCPuppet> = hit.target as NPCPuppet;
    let player: ref<PlayerPuppet> = hit.attackData.GetInstigator() as PlayerPuppet;
    let now: Float;
    let effects: ref<StatusEffectSystem>;
    let pending: array<SHitStatusEffect>;
    if !IsDefined(target) || !IsDefined(player) || target.IsDead() || target.IsAboutToDie() {
      return;
    };
    if hit.attackData.HasFlag(hitFlag.DealNoDamage) || hit.attackData.HasFlag(hitFlag.DamageNullified) || hit.attackComputed.GetTotalAttackValue(gamedataStatPoolType.Health) <= 0.00 {
      return;
    };
    now = INE_Combat.Now(target);
    // Runtime-only mark: do not apply another hostile status after native
    // stealth Stun has resolved. The first hit has already dealt its damage.
    target.ineVulnerableUntil = now + 10.00;
    // Preserve Blue Fang's actual native Stun application. Only adjust the
    // lifetime of a NEW stun from this Inevitable stealth head hit; never
    // remove/reapply it, refresh an existing stun or edit the global record.
    if !hadNativeStun && hit.attackData.HasFlag(hitFlag.StealthHit) && INE_Combat.HeadHit(hit) {
      effects = GameInstance.GetStatusEffectSystem(target.GetGame());
      pending = hit.attackData.GetStatusEffects();
      for effect in pending {
        if effect.id == t"BaseStatusEffect.Stun" && effects.HasStatusEffect(target.GetEntityID(), effect.id) {
          effects.SetStatusEffectRemainingDuration(target.GetEntityID(), effect.id, 5.00);
        };
      };
    };
  }
}

// Head-only gate around the stock application, scoped to Inevitable's
// stealth hits and native Stun. Head hits still run the original body.
@wrapMethod(AddStatusEffectToAttackEffector)
protected func RepeatedAction(owner: ref<GameObject>) -> Void {
  let hit: ref<gameHitEvent> = this.GetHitEvent();
  if this.m_statusEffect.id == t"BaseStatusEffect.Stun" && INE_Combat.InevitableHit(hit) {
    if hit.attackData.HasFlag(hitFlag.StealthHit) && !INE_Combat.HeadHit(hit) {
      return;
    };
  };
  wrappedMethod(owner);
}

// Combat head detection only. All stun application uses the stock
// AddStatusEffectToAttackEffector; the stealth branch has no custom prereq.
public class INE_CombatHeadPrereq extends GenericHitPrereq {
  protected func Initialize(recordID: TweakDBID) -> Void {
    super.Initialize(recordID);
    ArrayPush(this.m_conditions, new INE_CombatHeadCondition());
  }
}

public class INE_CombatHeadPrereqState extends GenericHitPrereqState {}

public class INE_CombatHeadCondition extends BaseHitPrereqCondition {
  public func Evaluate(hitEvent: ref<gameHitEvent>) -> Bool {
    let target: ref<NPCPuppet>;
    if !INE_Combat.InevitableHit(hitEvent) || !INE_Combat.HeadHit(hitEvent) || hitEvent.attackData.HasFlag(hitFlag.StealthHit) {
      return false;
    };
    target = hitEvent.target as NPCPuppet;
    return IsDefined(target) && !StatusEffectSystem.ObjectHasStatusEffectOfType(target, gamedataStatusEffectType.Stunned);
  }
}

@wrapMethod(DamageSystem)
private final func ProcessPipeline(hitEvent: ref<gameHitEvent>, cache: ref<CacheData>) -> Void {
  let target: ref<NPCPuppet>;
  let eligible: Bool = INE_Combat.InevitableHit(hitEvent);
  let hadNativeStun: Bool;
  if eligible {
    target = hitEvent.target as NPCPuppet;
    if IsDefined(target) {
      hadNativeStun = StatusEffectSystem.ObjectHasStatusEffect(target, t"BaseStatusEffect.Stun");
      // Snapshot before any part of this hit can alert the target.
      hitEvent.attackData.ineSilentStunCandidate = !hadNativeStun && !NPCPuppet.IsInCombat(target) && !AttackData.IsPlayerInCombat(hitEvent.attackData) && INE_Combat.HeadHit(hitEvent);
      hitEvent.attackData.ineSilentStunApplied = false;
    };
  };
  wrappedMethod(hitEvent, cache);
  if eligible && IsDefined(target) {
    INE_Combat.AfterHit(hitEvent, hadNativeStun);
  };
}

// Resolve a successful stealth head stun BEFORE native hit reactions and
// their combat stimuli. The native Stun and all its immunity/AI data remain.
@wrapMethod(DamageSystem)
private final func ProcessHitReaction(hitEvent: ref<gameHitEvent>) -> Void {
  let target: ref<NPCPuppet>;
  let player: ref<PlayerPuppet>;
  let effects: ref<StatusEffectSystem>;
  if INE_Combat.InevitableHit(hitEvent) && hitEvent.attackData.ineSilentStunCandidate && hitEvent.attackData.HasFlag(hitFlag.StealthHit) && INE_Combat.HeadHit(hitEvent) && hitEvent.attackComputed.GetTotalAttackValue(gamedataStatPoolType.Health) > 0.00 {
    target = hitEvent.target as NPCPuppet;
    player = hitEvent.attackData.GetInstigator() as PlayerPuppet;
    if IsDefined(target) && IsDefined(player) && !target.IsDead() && !target.IsAboutToDie() && !hitEvent.attackData.WasBlocked() && !hitEvent.attackData.WasDeflectedAny() && !hitEvent.attackData.HasFlag(hitFlag.FriendlyFireIgnored) && NotEquals(GameObject.GetAttitudeTowards(target, player), EAIAttitude.AIA_Friendly) {
      effects = GameInstance.GetStatusEffectSystem(target.GetGame());
      if GameInstance.GetStatsSystem(target.GetGame()).GetStatValue(Cast<StatsObjectID>(target.GetEntityID()), gamedataStatType.StunImmunity) <= 0.00 {
        // Attach too, so PostProcess sees the same native status entry.
        // Its native immunity check prevents a second application/refresh.
        hitEvent.attackData.AddStatusEffect(t"BaseStatusEffect.Stun", 1.00);
        effects.ApplyStatusEffect(target.GetEntityID(), t"BaseStatusEffect.Stun", player.GetRecordID(), player.GetEntityID());
      };
      if effects.HasStatusEffect(target.GetEntityID(), t"BaseStatusEffect.Stun") {
        hitEvent.attackData.ineSilentStunApplied = true;
        hitEvent.attackData.AddFlag(hitFlag.DisableNPCHitReaction, n"INE_SilentHeadStun");
        effects.SetStatusEffectRemainingDuration(target.GetEntityID(), t"BaseStatusEffect.Stun", 5.00);
      };
    };
  };
  wrappedMethod(hitEvent);
}

// Do not let this successful silent stun immediately identify the shooter.
// All other attacks, kills, witnesses and normal vision detection pass through.
@wrapMethod(TargetTrackingExtension)
public final static func OnHit(ownerPuppet: wref<ScriptedPuppet>, evt: ref<gameHitEvent>) -> Void {
  if INE_Combat.SilentControlHit(evt) { return; };
  wrappedMethod(ownerPuppet, evt);
}

@wrapMethod(ScriptedPuppet)
protected func HandleStimsOnHit(evt: ref<gameHitEvent>) -> Void {
  if INE_Combat.SilentControlHit(evt) { return; };
  wrappedMethod(evt);
}

@wrapMethod(ScriptedPuppet)
protected cb func OnDamageReceived(evt: ref<gameDamageReceivedEvent>) -> Bool {
  if IsDefined(evt) && INE_Combat.SilentControlHit(evt.hitEvent) { return false; };
  return wrappedMethod(evt);
}

@wrapMethod(DamageSystem)
private final func CalculateSourceVsTargetModifiers(hitEvent: ref<gameHitEvent>) -> Void {
  let target: ref<NPCPuppet>;
  wrappedMethod(hitEvent);
  if !INE_Combat.DirectPlayerWeaponHit(hitEvent) {
    return;
  };
  target = hitEvent.target as NPCPuppet;
  if !IsDefined(target) || target.ineVulnerableUntil <= INE_Combat.Now(target) {
    return;
  };
  // One multiplier, before the native one-shot protection and health handling.
  hitEvent.attackComputed.MultAttackValue(1.10);
}

// A custom item can enter stock through native item queries, even without an
// explicit vendor entry. Also filters stock previously cached in a save.
@wrapMethod(Vendor)
public final func GetItemsForSale(checkPlayerCanBuy: Bool) -> array<SItemStack> {
  let source: array<SItemStack> = wrappedMethod(checkPlayerCanBuy);
  let kept: array<SItemStack>;
  for entry in source {
    if ItemID.GetTDBID(entry.itemID) != t"Items.Inevitable" {
      ArrayPush(kept, entry);
    };
  };
  return kept;
}

// Remove the inherited tier-dependent recovery curve from this item only.
// The explicit ten-second base remains subject to the player's normal perks.
public class INE_RecoverySetup extends ScriptableTweak {
  protected cb func OnApply() -> Void {
    let source: array<TweakDBID> = FromVariant<array<TweakDBID>>(TweakDBInterface.GetFlat(t"Items.Inevitable.statModifiers"));
    let kept: array<TweakDBID>;
    let stat: TweakDBID;
    for modifier in source {
      stat = FromVariant<TweakDBID>(TweakDBInterface.GetFlat(modifier + t".statType"));
      if stat != t"BaseStats.ThrowRecovery" || modifier == t"Items.INE_Recovery" {
        ArrayPush(kept, modifier);
      };
    };
    TweakDBManager.SetFlat(t"Items.Inevitable.statModifiers", ToVariant(kept));
    TweakDBManager.UpdateRecord(t"Items.Inevitable");
  }
}

// Reuse the ACTUAL native Blue Fang stealth effector, with its existing
// prerequisite tree, native Stun ID, duration, AI data and immunity packages.
// Resolve generated inline IDs at runtime so no guessed ID can silently fail.
public class INE_BlueFangSetup extends ScriptableTweak {
  protected cb func OnApply() -> Void {
    let packages: array<TweakDBID> = FromVariant<array<TweakDBID>>(TweakDBInterface.GetFlat(t"Items.IconicNeurotoxinKnifeWeaponMod.OnAttach"));
    let effectors: array<TweakDBID>;
    let selected: array<TweakDBID>;
    let status: TweakDBID;
    for packageID in packages {
      effectors = FromVariant<array<TweakDBID>>(TweakDBInterface.GetFlat(packageID + t".effectors"));
      for effector in effectors {
        status = FromVariant<TweakDBID>(TweakDBInterface.GetFlat(effector + t".statusEffect"));
        if status == t"BaseStatusEffect.Stun" {
          ArrayPush(selected, effector);
        };
      };
    };
    // Add only the original immediate stealth branch, not Blue Fang's two
    // delayed combat branches. Our existing combat head rule stays separate.
    ArrayPush(selected, t"Items.INE_CombatStunEffector");
    TweakDBManager.SetFlat(t"Items.INE_Ability.effectors", ToVariant(selected));
    TweakDBManager.UpdateRecord(t"Items.INE_Ability");
  }
}
