use std::{env,fs,process};
use redscript_ast::SourceMap;
fn main() {
 let files = SourceMap::new(); let mut failed=false;
 for path in env::args().skip(1) {
  let src=fs::read_to_string(&path).unwrap();
  let id=files.push_back(&path,src.clone());
  let (_,errors)=redscript_parser::parse_module(&src,id);
  if errors.is_empty(){println!("PARSE PASS {path}");}
  else {failed=true;for e in errors {eprintln!("PARSE FAIL {path}: {e:?}");}}
 }
 if failed {process::exit(1)}
}
