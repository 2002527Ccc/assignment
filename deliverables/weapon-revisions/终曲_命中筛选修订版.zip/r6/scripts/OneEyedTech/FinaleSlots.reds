module FinaleSlots

public abstract class FSL_Slots {
  public static func All() -> array<TweakDBID> {
    return [t"AttachmentSlots.FSL_TechMod1", t"AttachmentSlots.FSL_TechMod2", t"AttachmentSlots.FSL_TechMod3", t"AttachmentSlots.FSL_TechMod4"];
  }
  public static func Contains(slot: TweakDBID) -> Bool {
    let allSlots: array<TweakDBID> = FSL_Slots.All();
    return ArrayContains(allSlots, slot);
  }
  public static func Append(slots: array<TweakDBID>) -> array<TweakDBID> {
    let result: array<TweakDBID> = slots;
    for slot in FSL_Slots.All() {
      if !ArrayContains(result, slot) { ArrayPush(result, slot); };
    };
    return result;
  }
}

// Finale alone owns Items.FSL_Blueprint and these four unique slot IDs.
// This compatibility bridge never adds a blueprint or slot to another weapon.
// It only permits items that *already* accept a vanilla Tech Handgun mod slot
// to be placed in Finale's FSL slots. Avoid redundant TweakDB record updates.
public class FSL_Compatibility extends ScriptableTweak {
  protected cb func OnApply() -> Void {
    let slots: array<TweakDBID>;
    let compatible: Bool;
    let complete: Bool;
    for record in TweakDBInterface.GetRecords(n"gamedataItem_Record") {
      slots = TweakDBInterface.GetForeignKeyArray(record.GetID() + t".placementSlots");
      compatible = ArrayContains(slots, t"AttachmentSlots.Tech_Handgun_WeaponMod1") || ArrayContains(slots, t"AttachmentSlots.Tech_Handgun_WeaponMod2");
      if compatible {
        complete = ArrayContains(slots, t"AttachmentSlots.FSL_TechMod1") && ArrayContains(slots, t"AttachmentSlots.FSL_TechMod2") && ArrayContains(slots, t"AttachmentSlots.FSL_TechMod3") && ArrayContains(slots, t"AttachmentSlots.FSL_TechMod4");
        if !complete {
          slots = FSL_Slots.Append(slots);
          TweakDBManager.SetFlat(record.GetID() + t".placementSlots", ToVariant(slots));
          TweakDBManager.UpdateRecord(record.GetID());
        };
      };
    };
  }
}

@wrapMethod(InventoryDataManagerV2)
public final static func GetAttachmentSlotsForInventory() -> array<TweakDBID> {
  return FSL_Slots.Append(wrappedMethod());
}

@wrapMethod(UIInventoryItemModsStaticData)
public final static func GetAttachmentSlots(itemType: gamedataItemType) -> array<TweakDBID> {
  let slots: array<TweakDBID> = wrappedMethod(itemType);
  if Equals(itemType, gamedataItemType.Wea_Handgun) {
    return FSL_Slots.Append(slots);
  };
  return slots;
}

@wrapMethod(RPGManager)
public final static func GetModsSlotIDs(type: gamedataItemType) -> array<TweakDBID> {
  let slots: array<TweakDBID> = wrappedMethod(type);
  if Equals(type, gamedataItemType.Wea_Handgun) {
    return FSL_Slots.Append(slots);
  };
  return slots;
}

@wrapMethod(UIItemsHelper)
public final static func GetSlotShadowIcon(slotID: TweakDBID, itemType: gamedataItemType, equipmentArea: gamedataEquipmentArea) -> CName {
  if Equals(itemType, gamedataItemType.Wea_Handgun) && FSL_Slots.Contains(slotID) { return n"UIIcon.ItemShadow_Mod"; };
  return wrappedMethod(slotID, itemType, equipmentArea);
}

@wrapMethod(UIItemsHelper)
public final static func GetLootingShadowIcon(slotID: TweakDBID, itemType: gamedataItemType, equipmentArea: gamedataEquipmentArea) -> CName {
  if Equals(itemType, gamedataItemType.Wea_Handgun) && FSL_Slots.Contains(slotID) { return n"UIIcon.LootingShadow_Mod"; };
  return wrappedMethod(slotID, itemType, equipmentArea);
}

@wrapMethod(UIItemsHelper)
public final static func GetEmptySlotName(slotId: TweakDBID) -> String {
  if FSL_Slots.Contains(slotId) { return "UI-Labels-EmptyModSlot"; };
  return wrappedMethod(slotId);
}

@wrapMethod(UIItemsHelper)
public final static func GetSlotName(slotID: TweakDBID, itemType: gamedataItemType, equipmentArea: gamedataEquipmentArea) -> String {
  if Equals(itemType, gamedataItemType.Wea_Handgun) && FSL_Slots.Contains(slotID) { return "Gameplay-Items-Item Type-Prt_Mod"; };
  return wrappedMethod(slotID, itemType, equipmentArea);
}
