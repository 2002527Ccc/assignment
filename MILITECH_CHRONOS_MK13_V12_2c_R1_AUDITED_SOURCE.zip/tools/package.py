"""Build and verify the complete install ZIP. Run only after validation."""
import hashlib, pathlib, zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
DIST=ROOT.parent/'dist'; DIST.mkdir(exist_ok=True)
name='MILITECH_CHRONOS_MK13_V12_2c_R1_AUDITED_SOURCE.zip'
files=sorted(p for p in ROOT.rglob('*') if p.is_file() and p.name!='MANIFEST.sha256' and '__pycache__' not in p.parts)
required=['r6/scripts/ChronosTemporalCompensation.reds','r6/scripts/ChronosDeflection.reds',
          'r6/scripts/ChronosLocalization.reds','r6/tweaks/chronos/chronos_mk13.yaml',
          'bin/x64/plugins/cyber_engine_tweaks/mods/MilitechChronosMK13/init.lua']
assert all((ROOT/p).is_file() for p in required)
assert not (ROOT/'r6/scripts/ChronosTechCharge.reds').exists()
assert not (ROOT/'r6/scripts/ChronosVisualControl.reds').exists()
manifest=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(ROOT).as_posix()+'\n' for p in files)
(ROOT/'MANIFEST.sha256').write_text(manifest)
files.append(ROOT/'MANIFEST.sha256')
output=DIST/name
with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):
  arc=p.relative_to(ROOT).as_posix(); assert not arc.startswith('/') and '..' not in pathlib.PurePosixPath(arc).parts
  info=zipfile.ZipInfo(arc,date_time=(2026,10,31,0,0,0)); info.compress_type=zipfile.ZIP_DEFLATED
  info.external_attr=0o100644<<16
  z.writestr(info,p.read_bytes())
with zipfile.ZipFile(output) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(set(z.namelist()))==len(files)
 for p in files: assert z.read(p.relative_to(ROOT).as_posix())==p.read_bytes()
 assert all(p in z.namelist() for p in required)
sha=hashlib.sha256(output.read_bytes()).hexdigest()
(DIST/(name+'.sha256')).write_text(sha+'  '+name+'\n')
report=f'Complete install layout: PASS\nZIP CRC: PASS\nDuplicate/traversal paths: PASS\nAll {len(files)} file bytes match source: PASS\nSHA256 manifest: generated\nArchive bytes: {output.stat().st_size}\nArchive SHA256: {sha}\nGame compile / TweakXL / Vortex install / playtest: NOT RUN\n'
(DIST/'package-results.txt').write_text(report)
print(report)
