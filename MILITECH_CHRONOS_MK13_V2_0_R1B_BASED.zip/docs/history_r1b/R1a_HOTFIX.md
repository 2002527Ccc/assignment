# CHRONOS V12.2c R1a — REDscript compatibility hotfix

Evidence: redscript_rCURRENT(8).log, 2026-10-31 17:43.

Fixed: r6/scripts/ChronosDeflection.reds, original line 23.
Removed unsupported `LogChannel(n"DEBUG", "[CHRONOS] ranged hit deflected")` and its debug-only conditional. This is instrumentation only; the chance calculation and `MultAttackValue(0.0)` are unchanged.

Validated locally: source ZIP CRC, replacement uniqueness, package SHA-256 manifest, new ZIP CRC.
Not validated: game 2.5 REDscript compilation, TweakXL loading, CET/runtime behavior.

Install: disable/remove R1 and all earlier Chronos versions in Vortex, deploy R1a only, launch game, collect newest `r6/logs/redscript_*.log` if another error is reported.
