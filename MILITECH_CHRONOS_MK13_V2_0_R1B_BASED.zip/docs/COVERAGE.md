# 冷却和功能覆盖清单

**本表是实际源码接入范围，不是已完成的游戏测试清单。全义体100%覆盖尚未成立。**

## 冷却通路

|对象|具体接入|执行条件/尚未覆盖|
|---|---|---|
|光学迷彩|玩家OpticalCamoCharges|仅原生Regeneration启用、没有Decay/延迟、可观测进度减慢时补偿；使用时长不延长|
|弹丸发射器|玩家ProjectileLauncherCharges；ProjectileLauncherCooldown状态候选|Relic/多充能的单位、边界需实机；非玩家宿主不猜测|
|血泵、医疗物品|玩家HealingItemsCharges|恢复原生池进度；不修改治疗量、使用动作或生命扣除|
|生物监测器|共享医疗充能走HealingItemsCharges；独立状态冷却按标签/原生Duration属性识别|不能据此断言所有内部触发CD均相同；无状态/池的私有timer未覆盖|
|克伦奇科夫|BaseStatusEffect.KerenzikovCooldown；KerenzikovCooldownDuration关联组|只有IsAffectedByTimeDilationPlayer=true且实际减慢才补偿，已现实时间的原版CD不加速|
|第二心脏|BaseStatusEffect.SecondHeartCooldown；SecondHeartCooldownDuration关联组|只在Chronos真正运行时修正其状态倒计时；死亡/脱离即停，原生复活逻辑不变|
|反应调谐器/突触加速/同类触发义体|SynapticAcceleratorCooldown、ReflexRecorderCooldown候选；TimeDilationOnHealthDrop/OnDodges/WhenEnteringCombatCooldownDuration关联组|这些是源码里的具体ID/属性入口，不把中译名误当成同一实现；需本机日志确认关联|
|肾上腺素转换器等独立触发义体|实际带PlayerCyberwareCooldown标签，或上述Duration冷却属性时进入状态路径|私有DelaySystem、原生ICooldownSystem或共享TimeBank路径未接管|
|其他原生冷却|AutomaticReplenishmentCooldown、ElectroshockMechanismCooldown、IconicCyberwareCooldown、SuddenAidCooldown等候选|只有实际应用到玩家、标记受时缓影响的有限状态才操作；ID不存在就不会凭空添加|
|其他带标签状态|PlayerCyberwareCooldown|自定义状态同样须受时缓标记与自然进度检查；刷新/叠层重新采样|
|其他冷却属性关联状态|HolographicSkinCooldownDuration、MemoryTrackerCooldownDuration及上述三类时缓触发冷却|原生Duration组识别，关联组深度4；未命中不猜测为冷却|
|手雷|玩家GrenadesCharges|与其他四池相同的条件式再生补偿|
|投掷武器回收|未新增专用通路|不能把ThrowRecovery假定在玩家身上；不属于已完成覆盖|
|其他原生StatPool|没有全枚举修改|CWMask、载具导弹、TimeBank等未凭枚举存在就纳入|
|Chronos及其他Sandevistan|**明确排除**|不读写自身充能恢复配置，不缩短SandevistanCooldown，CooldownBase仍1.0|

## 哪些部分尚未完整实现

1. **所有私有原生CD的统一补偿**：2.5 ICooldownSystem只公开Register/Remove/DoesCooldownExist/GetCID等，没有剩余时间和可逆逐timer时标接口。改注册flag会影响关机后其他时缓，故未做。要扩展需对应原版调用点源码或额外native插件接口。
2. **StatPool恢复开始等待阶段**：只读检测延迟，不跳过原生startDelay，也未擅自写native modifier。等待本身是否受时缓影响需逐项实测；当前不保证该阶段现实时间正常。
3. **非玩家宿主及未暴露的TimeBank/Delay实现**：不把其他池当成通用计时器，暂未覆盖。
4. **双持两把技术枪同时充能**：当前只处理原生ActiveWeapon；Expanded Dual Wielding的第二只手独立池未接入。

## 与其他恢复/时标MOD

正常技能改变原生恢复率时，新样本按新rate重新建基线，不还原旧值。状态倒计时已经按现实时间走时不会再缩短。

如果另一MOD通过把池rate直接乘2.5或改ChargeTime来预补时缓，仅从当前状态无法区分它与合法技能加速；**不能承诺自动识别全部这种重复补偿**。对重叠的池用excludedPools单独排除，或关闭tech模块。不要改第三方文件。状态也可以按完整ID或诊断key排除。

## 技术武器范围

已实现：原生Tech枪械、WeaponCharge恢复进度、换枪/退出/读档清理、模块独立开关；不改ChargeTime或Bolt窗口。

待实机：Finale的普通充能、Bolt成功/失败窗口、穿透、黑墙、非原生私有timer、自定义充能曲线、30/60/120 FPS的队列顺序。仅存在源码路径不代表已兼容通过。

## 蓝滤镜范围

已实现：查询真实原生Sandevistan VFX资源并检测相机ColorGrade/ColorGradeV2轨；只终止该玩家的对应原生事件，其他非调色效果不停止。

待实机：本机蓝色滤镜是否确在这些资源中、原生Stop是否按预期释放全部颜色分级、首次异步载入的入场闪色、第三方视觉组合。若诊断显示suppressed=0且unresolved，说明未命中，不能标成去蓝成功。

没有做：全局LUT覆盖、空白相机时间曲线、缓存资源修改、滤镜反向抵消、外部引力/Nexus效果。
