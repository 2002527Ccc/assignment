# API与来源

## 本次新获得的2.5声明依据

NativeDB：
<https://github.com/rayshader/cp2077-nativedb/tree/8d418f04128ce43a4f70a47689895bb0e7ecda7b>

该仓库README明确标注game 2.5，src/assets/reddump包含压缩RTTI/类声明。本次直接读取其classes.json和文本声明，不把2021年的旧NativeDB冒充2.5。它仍不是用户本机的完整游戏bundle，也没有全部脚本方法体和TweakDB值。

已核对的关键接口：

|接口|用途|
|---|---|
|StatPoolsSystem.IsStatPoolModificationDelayed(StatsObjectID, StatPoolType) -> Bool|尊重原生恢复延迟|
|StatPoolsSystem.ToPercentage(StatsObjectID, StatPoolType, Float) -> Float|point单位转换|
|StatPoolsSystem.GetStatPoolMaxPointValue(...) -> Float|零上限转换保护|
|StatusEffectSystem.GetAppliedEffects(EntityID, out array<ref<StatusEffect>>)|查询当前玩家状态|
|StatusEffect_Record.IsAffectedByTimeDilationPlayer() -> Bool|避免给已不受时缓的状态额外加速|
|StatusEffect.GetRemainingDuration/GetLastApplicationSimTimestamp/GetStackCount|观察自然进度/刷新/叠层|
|StatModifierGroup_Record.StatModifiers/RelatedModifierGroups及Combined.RefStat|只在有依据的冷却属性关联下补充识别|
|StatusEffect_Record.VFX(out array<wref<StatusEffectFX_Record>>)|定位真实原生效果名|
|GameObjectEffectHelper.StopEffectEvent/StartEffectEvent|结束/恢复该玩家的已识别原生效果|
|GameObject.StartStatusEffectVFX|观察重施后再次清理已识别调色事件，不接管状态机|

Codeware公开声明：
<https://github.com/psiberx/cp2077-codeware/tree/decce71323d6f6183cf78143882032a3c70aac9e>

核对Entity.GetComponents、ResourceAsyncRef.GetPath/IsEmpty、GameInstance.GetResourceDepot、ResourceDepot.LoadResource、ResourceToken.IsLoaded/IsFailed/GetResource，以及worldEffect、EffectSpawner、ColorGrade轨的字段导出。实际停止的是确认含相机颜色分级轨的原生效果，未调用不存在/未经确认的直接LUT setter。

完整自动核对输出在API_DECLARATION_RESULTS.txt。检查是声明存在性/参数核对，不是游戏类型编译或调用成功证明。

## 其他参考

- RED4ext.SDK（明确patch 2.5类型更新）：<https://github.com/WopsS/RED4ext.SDK/commit/5246e659d783e5834cc08a90e56c8932c9ed3449>，用于池/属性/类型名称交叉核对。
- TweakXL InheritanceMap/解析器：<https://github.com/psiberx/cp2077-tweak-xl/tree/3875f1debedefd080f471b3db9b929566137eb88>，定位原生记录候选。没有用它替代完整2.5 flat dump；本版YAML未改。
- REDscript官方解析器：<https://github.com/jac3km4/redscript/tree/0c625df7784fea5e8078ee107a2b7ef2a580100e>，只运行语法检查，不伪造游戏符号来宣称编译通过。
- CET：<https://github.com/maximegmd/CyberEngineTweaks/tree/b160d68cf923f2535cb3a6ebe006de86ef21e359>，确认独立mod事件环境、实际帧delta及TweakDBID表示。实际业务离线检查改用LuaJIT 2.1/Lua 5.1。

没有捆绑第三方MOD源码/资源，不修改Finale、Inevitable、Fate、Kerenzikov XMOD2、Expanded Dual Wielding。兼容策略是只观察原生接口、只在精确Chronos运行态工作；第三方组合未实机，不能把结构隔离等同于兼容测试通过。

## 已确认的公开接口边界

2.5 ICooldownSystem公开Register/RegisterAbility/RegisterFromRecord、GetCID、DoesCooldownExist、Remove；未提供剩余时间查询或逐个已有timer时标修改。RegisterNewCooldownRequest虽然有affectedByTimeDilation，但把它永久设false会跨出Chronos生命周期，故未使用这种捷径。

没有原版方法体/本机记录证据时，不把所有生物监测器/血泵/触发义体都假定为同一CD，也不全局修改冷却时长、Sandevistan视觉或ChargeTime.min。
