# 验证结果

目标版本：用户确认2.5。构建标识：V12.2c-R1。

## 已执行

- 检查两个上传ZIP路径，安全解包；对比V12.2b/c全部运行源码。
- 输入四份REDscript由真实REDscript解析器解析：通过，说明原包当前不能简单归类为语法不通过。
- 输出三份REDscript由同一真实解析器解析：通过。
- 输出四份Lua文件由Lua实际load解析：通过。
- **35项行为测试**运行实际timing.lua/controller.lua：全部通过，完整逐项输出在offline-results.txt。
- YAML解析及独立命名空间、核心设计值、容量、原生Damage/Process、TweakXL mutation使用检查：通过。
- 17个直接在REDscript出现的枚举符号，核对RED4ext.SDK明确标注2.5更新的头文件：通过，见sdk-enums.txt。
- 打包后ZIP CRC、完整路径、路径穿越、文件清单和SHA256校验：见交付ZIP旁的外部打包日志package-results.txt和包内MANIFEST.sha256。

## 未执行、不能宣称通过

- **游戏2.5 REDscript完整编译/链接：未执行。** 容器无Cyberpunk2077.exe、final.redscripts、tweakdb.bin、原版2.5脚本符号和游戏运行时；实际搜索未发现这些文件。
- REDscript方法访问权限、目标2.5实际API签名、父类/回调兼容：只做源码核查，没有完整目标符号，不能由parser或SDK枚举检查代替。
- TweakXL实际加载：未执行。独立物品、容量变体、UI文本、原生通用包与inline引用仍需实机日志。
- 原生充能与反复启停：未执行。离线控制器100次启停通过仅说明自定义modifier不累加，不证明原生Sandevistan可再次启动。
- 原生Health死亡/治疗/读档、命中管线、格挡概率、减伤系统、真实冷却、技术/Bolt、其他MOD兼容：未执行。
- 新技术路径默认关闭，蓝滤镜移除和全义体映射未完成，不将这些项目计为跳过后“整体通过”。

## mock的实际边界

离线行为测试模拟了引擎依赖，验证的是**实际交付Lua控制器**的数学、状态转换、句柄回滚及范围控制。没有模拟/替换原生游戏类来骗过REDscript类型编译。模拟器的pool请求同步应用；真实引擎异步队列和事件顺序尚未验证。

## 复跑

Python3安装开发依赖（不属于游戏运行依赖）：

```
python -m pip install -r tools/requirements-dev.txt
python tools/validate.py
```

若已有真正的解析器驱动，设 `REDS_CHECK` 为可执行路径再跑；否则脚本明确报告REDscript parser未运行。`tools/reds-parser/`包含本次小驱动源码和固定官方Git提交的Cargo依赖，可自行构建。游戏完整编译应通过冷启动游戏及其redscript日志验证，不能把上述开发检查命令当成完整编译命令。

## 后续需要的证据

先回传真实redscript/TweakXL编译加载日志和CET诊断，修复任何实际签名或记录失败；再按TEST_PLAN逐组实测。要在离线环境继续真正类型编译，需要合法取得的目标2.5游戏脚本bundle及依赖，或具备游戏的执行环境。没有这些条件，本版不能命名为“稳定最终整合版”。
