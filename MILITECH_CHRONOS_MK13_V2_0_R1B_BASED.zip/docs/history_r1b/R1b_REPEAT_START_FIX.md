# R1b：原版斯安威斯坦重复启动修正（测试候选版）

## 实测前提
用户在R1a上已确认：第一次时缓减速正常、每现实秒生命损耗正常；首次关闭后不能再次启动。

## 原版代码依据
- `CyberwareAction.UseCooldownedSandevistan` 在充能池大于0时可启动；这是Apogee/Falcon使用的可部分充能启动动作。
- `BaseStatusEffect.CooldownedSandevistanPlayerBuff` 在退出后产生 `BaseStatusEffect.SandevistanCooldown`。
- `BaseStatusEffect.SandevistanCooldown` 的packages含 `BaseStats.HasSandevistan` `Multiplier=0`，在效果存续期禁止再次激活。
- 该冷却状态的持续时间来自 `TimeDilationSandevistanCooldownBase`。原版Apogee这一属性设为1秒。
- 旧Chronos设为0.0。0秒在状态效果系统中可能被解释为无到期/无法正常清理，因此属于与“只能开一次”直接吻合的高优先级嫌疑。

## 本次只改
1. `r6/tweaks/chronos/chronos_mk13.yaml`：`TimeDilationSandevistanCooldownBase`从0.0调整为1.0。不是修改全局记录，仅Chronos专有记录。
2. `init.lua`诊断功能：增加SandevistanCharge百分比和SandevistanCooldownActive打印。仅用户按原有诊断热键时调用，不干涉启停。
3. 原版PSM、其他斯安威斯坦、HP损耗、60%减速、120秒储备、1秒充能及格挡逻辑均未修改。

## 测试顺序
1. 完全关闭游戏；Vortex停用/卸载R1a和其他旧Chronos版本，安装此完整R1b包，再Deploy。
2. 启动游戏，进入安全区域，装备Chronos。确认第1次可以开启、关闭。
3. 等至少2~3现实秒，再次开启。如果成功，重复5次（包括未满充能时尝试）。
4. 若仍不行，用CET Bindings中现有 `CHRONOS: print diagnostic report` 热键，在刚关闭后与2~3秒后分别打印。
5. 重点看 `HasSandevistan`、`SandevistanCharge(percent)`、`SandevistanCooldownActive`、`SandevistanChargesRegenEnabled`（如果记录中可取得），并发送CET输出及TweakXL日志。不能仅凭REDscript编译日志判定运行时状态。

## 诊断解释
- `SandevistanCooldownActive=true` 持续3秒以上：冷却效果未正确退出，继续追查状态效果。
- Charge=0且不恢复：充能池再生被禁用/被时缓Buff锁住，检查`SandevistanPlayerBuff`的残留。
- Charge>0，Cooldown=false且HasSandevistan>0仍不能启动：应检查UseCooldownedSandevistan物品objectActions、Kerenzikov竞争时缓状态及其他输入/行为限制。

**状态：仅完成静态修改、代码和ZIP检查，未通过游戏2.5实机。该改动是高把握的根因测试，不是已验证的最终修复。**
