-- Execute the ACTUAL V2 entrypoint with a minimal CET host; this is not a game test.
local events,hotkeys,observers={},{},{}
registerForEvent=function(n,f)assert(not events[n], 'duplicate event '..n);events[n]=f end
registerHotkey=function(n,_,f)assert(not hotkeys[n], 'duplicate hotkey '..n);hotkeys[n]=f end
ObserveBefore=function(c,n,f)observers[#observers+1]={class=c,name=n,fn=f}end
ObserveAfter=ObserveBefore
local function id(name)return setmetatable({value=name,hash=name,length=#name},{__tostring=function(x)return x.value end,__eq=function(a,b)return a.value==b.value end})end
TweakDBID={new=id}
gamedataStatPoolType=setmetatable({},{__index=function(_,k)return k end})
local player={id=1,GetEntityID=function()return 1 end}
local weapon={id=2,GetItemID=function()return 'Items.Finale.TestFixture' end}
local charge=10
local writes={}
ChronosBridge={
 SameOwner=function(a,b)return a.id==b.id end,
 ControllerIsActive=function()return true end,IsRunning=function()return true end,IsSuspended=function()return false end,
 ActiveWeapon=function()return weapon end,IsTechGun=function(w)return w==weapon end,
 HasPool=function(v,k)return v.id==2 and k=='WeaponCharge' end,
 GetRegeneration=function()return {usingPointValues=true,valuePerSec=1,rangeEnd=3,enabled=true}end,
 GetDecay=function()return {enabled=false,valuePerSec=0}end,
 ReadPercent=function()return charge end,
 ChangePercent=function(v,k,n)writes[#writes+1]={owner=v.id,kind=k,value=n};charge=charge+n end,
}
ChronosV2Queries={
 PoolToPercent=function(v,k,x)return x/3*100 end,PoolDelayed=function()return false end,
 Statuses=function()return {}end,RecordUsesCooldownStat=function()return false end,
 VisualTargets=function()return {}end,
}
Game={GetPlayer=function()return player end}
local exported=dofile(TEST_ENTRYPOINT)
local cfg=require('config');cfg.enabled.cooldowns=false;cfg.enabled.visual=false
assert(events.onInit and events.onUpdate and events.onShutdown)
events.onInit()
assert(#observers==4,'observers must register once')
events.onUpdate(.05) -- module start
events.onUpdate(.05) -- first charge sample
charge=charge+(.4/3*100*.05)
events.onUpdate(.05)
assert(#writes==1)
assert(math.abs(writes[1].value-1)<.000001,'point rate must be converted to percent')
assert(writes[1].owner==2 and writes[1].kind=='WeaponCharge')
for _=1,10 do events.onUpdate(.05)end
assert(#observers==4,'onUpdate must never add observers')
hotkeys.chronos_v2_toggle_tech()
local n=#writes
events.onUpdate(.05);assert(#writes==n,'disabled tech must not write pool')
hotkeys.chronos_v2_toggle_cooldowns();assert(cfg.enabled.cooldowns and not cfg.enabled.tech and not cfg.enabled.visual)
hotkeys.chronos_v2_toggle_visual();assert(cfg.enabled.visual and cfg.enabled.cooldowns and not cfg.enabled.tech)
events.onShutdown()
assert(exported.diagnostics)
print('PASS V2 actual entrypoint: point conversion, owner scope, hotkey and single registration')
return 4
