# 安装、升级、卸载

## 依赖与范围

目标版本按用户确认为Cyberpunk 2077 **2.5**。使用适配此版本的RED4ext、redscript、TweakXL、Cyber Engine Tweaks、Codeware。Codeware负责独立中英文文本；不要求额外视觉MOD。不重新分发第三方框架或终曲/在劫等MOD。原PNG仅为参考画，未编成游戏图标；当前沿用原版图标。

## 清理旧版本（游戏关闭时）

1. 先备份存档和旧Chronos包。在Vortex禁用/卸载旧Chronos，清理部署后再安装R1，避免同时启用两个版本。
2. 手动安装用户：只删除确认属于旧Chronos的以下文件，保留其他MOD：
   - `r6/scripts/ChronosDeflection.reds`
   - `r6/scripts/ChronosTechCharge.reds`
   - `r6/scripts/ChronosTemporalCompensation.reds`
   - `r6/scripts/ChronosVisualControl.reds`
   - `r6/tweaks/chronos/chronos_mk13.yaml`
   - `bin/x64/plugins/cyber_engine_tweaks/mods/MilitechChronosMK13/` 旧目录
3. 若之前自行把Chronos文件放进子目录，搜索并清理重复类/脚本。尤其不要保留旧 `ChronosTechCharge.reds` 和 `ChronosVisualControl.reds`：它们引用旧类，会与新实现不一致。
4. 不批量删除游戏脚本缓存或其他MOD文件。本包无需修改游戏原始archive，也没有需要删除的自带.archive。

## 安装和首次验证

- Vortex：安装本ZIP，确认部署根识别为游戏根目录，包含 `r6/scripts`、`r6/tweaks` 和 `bin/x64/plugins/cyber_engine_tweaks/mods`。
- 手动：复制根目录 `r6`、`bin`。`docs`、`tools`、`assets-source`是维护资料，不参与运行。
- 冷启动游戏，先检查 `r6/logs/redscript_rCURRENT.log` 和 `red4ext/logs/TweakXL*.log`。如本机日志命名不同，按实际最新时间查找。编译失败时不要把“进了启动器”当成通过。
- 进测试存档后CET获取：`Game.AddToInventory("Items.MilitechChronosMk13", 1)`。
- 升级后在义体医生处卸下再重新装备Chronos，使OnEquip包重新计算。不要在运行中热替换源码。
- CET Bindings内绑定 `CHRONOS: print diagnostic report`，输出位于CET控制台/该MOD日志。它会报告运行标志、关键属性、充能池和可见冷却。
- `config.lua` 的 `debug=true` 开启每秒汇总日志；不要正式游玩时持续打印大量命中日志。`tech=false` 是当前已明确未验收功能的默认状态。

## 卸载

1. 在游戏中关闭Chronos、卸下义体，装备原版操作系统后另存。
2. 完全退出游戏。Vortex卸载本包并清理部署；手动删除上述Chronos路径及本版 `r6/scripts/ChronosLocalization.reds`。
3. 不删除RED4ext、redscript、TweakXL、CET、Codeware或其他MOD。重新冷启动并检查日志。
4. 保存文件内已有的自定义物品不会因文件删除自动变成原版物品；保留升级前备份存档以便回退。
