# 安装、独立开关及回退

## 安装

1. 保留已验证的R1b ZIP和测试存档。退出游戏，在Vortex停用/卸载旧Chronos版本并清理部署，安装本完整2.0 ZIP，只部署一个Chronos版本。
2. 包根目录的r6/bin直接对应游戏根目录。包含两个CET目录是正常的：`MilitechChronosMK13`负责原R1b核心，`MilitechChronosMK13V2`只负责新功能。不要把两个目录合并。
3. 原三份.reds和原YAML已经包含在包中；新增ChronosV2Queries.reds、ChronosV2VisualQueries.reds。不要同时保留其他版本的重复类或旧ChronosTechCharge/ChronosVisualControl脚本。
4. 沿用适配游戏2.5的RED4ext、redscript、TweakXL、CET、Codeware。新增视觉接口依赖Codeware的Entity/ResourceDepot和原生类型字段导出。没有额外Nexus视觉依赖，无新.archive。
5. 冷启动先检查最新redscript/TweakXL日志，再进测试存档。原ID和获取命令不变。

## 三个开关

编辑：

`bin/x64/plugins/cyber_engine_tweaks/mods/MilitechChronosMK13V2/config.lua`

```lua
enabled = {tech = true, cooldowns = true, visual = true}
```

三个开关独立，false会完整停用对应新功能。默认全开是为了验证新实现；第一轮推荐全关对照原R1b，再逐项开。编辑配置后关闭Chronos并冷启动游戏。

CET Bindings也有独立热键：

- CHRONOS V2: toggle tech
- CHRONOS V2: toggle cooldowns
- CHRONOS V2: toggle visual
- CHRONOS V2: diagnostic report

热键只改本次会话，重启恢复config.lua。关闭visual时，如果Chronos仍在真实运行，会只恢复本模块停止的原生效果；实际OS退出/死亡/读档时不会重新开滤镜。

**保留旧目录config的tech=false与v2Features=true。** v2Features仅把旧可选冷却处理移交给V2，避免双重计算。要控制新功能，请使用新目录的开关，不要同时打开旧tech或重新启用旧冷却。

## 冲突排除和诊断

- 已有其他MOD处理某个池时，可设 `excludedPools = {HealingItemsCharges=true}`；它只退出新冷却模块的该池。
- 状态可按完整TweakDBID名称或诊断key排除：`excludedStatuses = {['BaseStatusEffect.SecondHeartCooldown']=true}`。
- 已有全局技术蓄力修复时，先关闭本包tech模块做对照；不能保证自动识别所有对原生rate/ChargeTime做过的第三方修复。
- debug=true打开候选识别日志；默认不每帧打印。诊断热键报告原生受时缓标志、原始point参数、归一化rate/limit、状态选择、调色轨停止数量和模块错误。
- 看到 `FEATURE DISABLED` 表示该新模块失败，不等于功能已正常运行；R1b核心不由此被重构或停用。
- 旧核心日志仍保留历史R1版本字样，这是逐字节保留的结果；新扩展日志以前缀 `[CHRONOS V2]` 为准。

## 编译问题隔离

运行时开关不能跳过REDscript的启动编译。若仅新增视觉查询报错，可在测试副本中把ChronosV2VisualQueries.reds改成非.reds后缀，并将visual=false，其余查询不依赖视觉类。真正回退推荐直接卸载2.0并重新安装R1b，不手工改已经验证的核心。

## 回退/卸载

关闭Chronos、退出游戏，在Vortex卸载2.0并清理部署，再安装原R1b ZIP。这样恢复两处可选移交改动并删除新目录/新查询。手动用户还必须删除新CET目录MilitechChronosMK13V2和两份ChronosV2*.reds；恢复原R1b的controller.lua/config.lua。

不要删除其他MOD或框架，不需要修改游戏原始archive。原R1、R1b上传文件及旧下载构建没有被本任务重写。
