"""Offline V2 checks. No game compiler/linker or engine is emulated here.
Requires Python 3, PyYAML and lupa. REDS_CHECK optionally points to the real parser.
"""
import hashlib,json,os,pathlib,subprocess
import yaml
from lupa.luajit21 import LuaRuntime
ROOT=pathlib.Path(__file__).resolve().parents[1]
MODS=ROOT/'bin/x64/plugins/cyber_engine_tweaks/mods'
BASE=MODS/'MilitechChronosMK13';V2=MODS/'MilitechChronosMK13V2'
def digest(b):return hashlib.sha256(b).hexdigest()
protected=json.loads((ROOT/'docs/R1B_PROTECTED_HASHES.json').read_text())
for name,sha in protected.items():assert digest((ROOT/name).read_bytes())==sha,name
baseline=json.loads((ROOT/'docs/R1B_CORE_METHOD_HASHES.json').read_text())
controller=(BASE/'modules/controller.lua').read_text()
guard='  if self.config.v2Features then return end -- optional cooldowns owned by independent V2 module\n'
assert controller.count(guard)==1
assert digest(controller.replace(guard,'').encode())==baseline['controller_sha256']
line='  v2Features = true, -- transfer ONLY optional cooldown correction; R1b core unchanged\n'
config=(BASE/'config.lua').read_text();assert config.count(line)==1
assert digest(config.replace(line,'').encode())==baseline['config_sha256']
for name,sha in baseline['core_method_sha256'].items():
 marker='function Controller.'+name if name=='new' else 'function Controller:'+name
 start=controller.index(marker);end=controller.find('\nfunction Controller',start+1)
 if end==-1:end=controller.index('\nreturn Controller',start)
 assert digest(controller[start:end].encode())==sha,name
print('R1b protected files, entire controller except one optional guard, and core methods: BYTE-IDENTITY PASS',flush=True)

def runtime(mod):
 l=LuaRuntime(unpack_returned_tuples=True);l.globals().package.path=str(mod/'?.lua');l.globals().print=lambda *args:print(*args,sep='\t',flush=True);return l
print('Lua backend:', runtime(V2).eval('jit.version'), flush=True)
parsed=0
for mod in (BASE,V2):
 l=runtime(mod)
 for p in sorted(mod.rglob('*.lua')):
  l.eval('function(s,n)local f,e=(loadstring or load)(s,n);assert(f,e);end')(p.read_text(),str(p.relative_to(ROOT)))
  parsed+=1
print(f'{parsed} runtime Lua files: PARSE PASS',flush=True)
l=runtime(BASE);base_count=l.execute((ROOT/'tools/tests/runtime_spec.lua').read_text())
l=runtime(V2);v2_count=l.execute((ROOT/'tools/tests/v2_spec.lua').read_text())
l=runtime(V2);l.globals().TEST_ENTRYPOINT=str(V2/'init.lua');adapter_count=l.execute((ROOT/'tools/tests/v2_adapter_spec.lua').read_text())
print(f'Offline behavior checks: R1b={base_count}, V2={v2_count}, adapter={adapter_count}; ALL PASS',flush=True)
class Loader(yaml.SafeLoader):pass
for tag in ('!remove-all','!append-from','!append'):
 Loader.add_constructor(tag,lambda loader,node:{'op':node.tag,'value':loader.construct_scalar(node)})
records=yaml.load((ROOT/'r6/tweaks/chronos/chronos_mk13.yaml').read_text(),Loader=Loader)
values={v['statType']:v['value'] for v in records['Items.MilitechChronosMk13']['statModifiers']}
for k,v in {'TimeDilationSandevistanCooldownBase':1,'TimeDilationSandevistanDuration':120,'TimeDilationSandevistanTimeScale':.4,'TimeDilationSandevistanRechargeDuration':1,'TimeDilationSandevistanEnterCost':0}.items():assert values['BaseStats.'+k]==v,k
print('R1b TweakXL records unchanged; restart cooldown remains 1.0: PASS',flush=True)
source='\n'.join(p.read_text() for p in V2.rglob('*.lua'))+'\n'.join(p.read_text() for p in (ROOT/'r6/scripts').glob('ChronosV2*.reds'))
for forbidden in ['SetTimeDilation(', 'SetTimeDilationOnLocalPlayer', 'DrainHealth(', 'SetControllerActive(', 'AddModifier(', 'RequestSettingModifier(', 'TweakDB:SetFlat(', 'LogChannel(']:assert forbidden not in source,forbidden
print('New extension has no OS/health/mitigation/global-record writes: PASS',flush=True)
checker=os.environ.get('REDS_CHECK')
if checker:subprocess.run([checker,*map(str,sorted((ROOT/'r6/scripts').glob('*.reds')))],check=True)
else:print('REDscript parser NOT RUN (set REDS_CHECK)',flush=True)
print('Game 2.5 compilation, engine queues, Bolt/Finale and actual blue-grade behavior: NOT RUN',flush=True)
