# MILITECH MK.13 — CHRONOS · V12.2c-R1

**这是完整安装结构的源码审查修订包，不是已通过游戏2.5编译和实机验收的稳定最终版。**

已直接重构代码并完成35项离线Lua行为测试、3份REDscript真实解析器检查、4份Lua语法检查和YAML结构检查。上述结果不能代替游戏API类型编译、TweakXL运行加载或实机测试。

本包仍有明确缺口：

- 尚无游戏2.5的 `final.redscripts` / TweakDB实际数据，不能验证原生储备公式、101容量显示及反复启动。
- 蓝色屏幕颜色分级移除尚未实现。旧版猜测VFX名称的停止调用已删除。
- 全义体冷却覆盖尚未完成；当前仅有四个候选玩家充能池和 `PlayerCyberwareCooldown` 标签的条件式补偿。
- 技术武器有独立的WeaponCharge进度补偿实现，但默认关闭；Bolt/Finale验证未完成，不能宣称功能已经交付可用。

这些缺口没有用被动描述冒充已完成能力，也没有改成其他设计数值。义体的基础设计仍为容量101、世界速度0.4、储备120秒、目标1现实秒充能、EnterCost=0。**这些是记录配置目标，不是已验证的实测结果。**

## 安装与获取

先看 [安装、卸载与旧版清理](docs/INSTALL.md)，不要与V12.2b/c旧文件并存。完整ZIP可交给Vortex，或把根目录 `r6`、`bin` 合并到游戏根目录。依赖游戏2.5适配版RED4ext、redscript、TweakXL、CET、Codeware；不捆绑这些框架。没有.archive文件，不需要引力视觉MOD。

CET控制台：

```lua
Game.AddToInventory("Items.MilitechChronosMk13", 1)
```

## 工程文件

- [逐模块实现与修复审查](docs/AUDIT.md)
- [实际功能、覆盖范围与未完成项目](docs/COVERAGE.md)
- [编译和离线验证证据](docs/VALIDATION.md)
- [实机验收步骤](docs/TEST_PLAN.md)
- [兼容性与参考来源](docs/COMPATIBILITY_AND_SOURCES.md)
- `tools/validate.py`、`tools/tests/runtime_spec.lua`：可复跑的离线检查。
- `docs/offline-results.txt`：本次真实执行输出。
- `docs/changes.diff`：相对V12.2c的运行源码变更。

要继续完成真正的最终验收，需要本机2.5的编译日志、TweakXL日志、CET诊断输出，以及实际原版脚本/记录或在游戏中运行测试的环境。当前容器没有游戏程序、脚本缓存或游戏引擎。
