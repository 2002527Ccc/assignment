module Inevitable

@wrapMethod(PlayerPuppet)
protected cb func OnItemAddedToInventory(evt: ref<ItemAddedEvent>) -> Bool {
  let result: Bool;
  let inevitableTierBeforeNativeInit: Float;
  let isInevitable: Bool = ItemID.IsValid(evt.itemID) && IsDefined(evt.itemData) && !ItemID.HasFlag(evt.itemID, gameEItemIDFlag.Preview) && ItemID.GetTDBID(evt.itemID) == t"Items.Inevitable";

  // Preserve the item's actual tier before vanilla converts iconic quality
  // into its saved upgrade counter. This also retains tiers on stash returns.
  if isInevitable {
    inevitableTierBeforeNativeInit = ClampF(Cast<Float>(RoundF(evt.itemData.GetStatValueByType(gamedataStatType.Quality))) * 2.00 + Cast<Float>(RoundF(evt.itemData.GetStatValueByType(gamedataStatType.IsItemPlus))), 0.00, 10.00);
  };

  result = wrappedMethod(evt);

  if isInevitable {
    this.INE_ApplyInevitableUpgradeState(evt.itemData, inevitableTierBeforeNativeInit);
  };

  return result;
}

// Read the actual displayed tier. Old saves can contain a stale upgrade
// counter even though this knife still displays Tier 1.
@addMethod(RPGManager)
public final static func INE_GetInevitableTier(itemData: wref<gameItemData>) -> Float {
  return ClampF(Cast<Float>(RoundF(itemData.GetStatValueByType(gamedataStatType.Quality))) * 2.00 + Cast<Float>(RoundF(itemData.GetStatValueByType(gamedataStatType.IsItemPlus))), 0.00, 10.00);
}

@addMethod(PlayerPuppet)
public final func INE_EnsureInevitableUpgradeState(itemData: wref<gameItemData>) -> Void {
  let tier: Float;
  if !IsDefined(itemData) || ItemID.GetTDBID(itemData.GetID()) != t"Items.Inevitable" {
    return;
  };
  if ItemID.HasFlag(itemData.GetID(), gameEItemIDFlag.Preview) {
    return;
  };
  tier = ClampF(Cast<Float>(RoundF(itemData.GetStatValueByType(gamedataStatType.Quality))) * 2.00 + Cast<Float>(RoundF(itemData.GetStatValueByType(gamedataStatType.IsItemPlus))), 0.00, 10.00);
  this.INE_ApplyInevitableUpgradeState(itemData, tier);
}

@addMethod(PlayerPuppet)
public final func INE_ApplyInevitableUpgradeState(itemData: wref<gameItemData>, tier: Float) -> Void {
  let stats: ref<StatsSystem>;
  let modifier: ref<gameStatModifierData>;
  if !IsDefined(itemData) || ItemID.GetTDBID(itemData.GetID()) != t"Items.Inevitable" {
    return;
  };
  if ItemID.HasFlag(itemData.GetID(), gameEItemIDFlag.Preview) {
    return;
  };
  stats = GameInstance.GetStatsSystem(this.GetGame());

  // Remove legacy fixed-quality offsets and stale upgrade counters together.
  // Rebuild only this instance using the two native iconic progression curves.
  stats.RemoveAllModifiers(itemData.GetStatsObjectID(), gamedataStatType.Quality, true);
  stats.RemoveAllModifiers(itemData.GetStatsObjectID(), gamedataStatType.IsItemPlus, true);
  stats.RemoveAllModifiers(itemData.GetStatsObjectID(), gamedataStatType.WasItemUpgraded, true);

  modifier = RPGManager.CreateStatModifier(gamedataStatType.WasItemUpgraded, gameStatModifierType.Additive, ClampF(tier, 0.00, 10.00));
  stats.AddSavedModifier(itemData.GetStatsObjectID(), modifier);
  modifier = RPGManager.CreateStatModifierUsingCurve(gamedataStatType.Quality, gameStatModifierType.Additive, gamedataStatType.WasItemUpgraded, n"quality_curves", n"iconic_upgrades_amount_to_quality");
  stats.AddSavedModifier(itemData.GetStatsObjectID(), modifier);
  modifier = RPGManager.CreateStatModifierUsingCurve(gamedataStatType.IsItemPlus, gameStatModifierType.Additive, gamedataStatType.WasItemUpgraded, n"quality_curves", n"iconic_upgrades_amount_to_plus");
  stats.AddSavedModifier(itemData.GetStatsObjectID(), modifier);

}

// Calculate this weapon's costs directly from its visible tier. Do not rely
// on an already-saved WasItemUpgraded value, and do not mutate tooltip queries.
@wrapMethod(CraftingSystem)
public final const func GetItemFinalUpgradeCost(itemData: wref<gameItemData>) -> array<IngredientData> {
  let ingredients: array<IngredientData>;
  let reduction: Float;
  let i: Int32;
  if !IsDefined(itemData) || ItemID.GetTDBID(itemData.GetID()) != t"Items.Inevitable" {
    return wrappedMethod(itemData);
  };

  ingredients = this.GetItemBaseUpgradeCost(itemData.GetItemType(), RPGManager.GetItemTierForUpgrades(RPGManager.INE_GetInevitableTier(itemData)));
  reduction = GameInstance.GetStatsSystem(this.GetGameInstance()).GetStatValue(Cast<StatsObjectID>(this.GetPlayerCraftBook().GetOwner().GetEntityID()), gamedataStatType.UpgradingCostReduction);
  i = 0;
  while i < ArraySize(ingredients) {
    ingredients[i].baseQuantity = ingredients[i].quantity;
    if reduction > 0.00 {
      ingredients[i].quantity = Cast<Int32>(Cast<Float>(ingredients[i].quantity) * (1.00 - reduction));
    };
    i += 1;
  };
  return ingredients;
}

// Vanilla UpgradeItem returns Void, so invoking it does not prove an upgrade
// was completed. First normalize legacy state; after vanilla runs, read the
// actual native WasItemUpgraded counter. Only commit our own tier if vanilla
// advanced it. This also prevents advancing after a failed/blocked upgrade.
@wrapMethod(CraftingSystem)
private final func UpgradeItem(owner: wref<GameObject>, itemID: ItemID) -> Void {
  let player: ref<PlayerPuppet>;
  let itemData: wref<gameItemData>;
  let afterData: wref<gameItemData>;
  let tier: Float;
  let nativeAfter: Float;
  if ItemID.GetTDBID(itemID) != t"Items.Inevitable" {
    wrappedMethod(owner, itemID);
    return;
  };
  player = owner as PlayerPuppet;
  itemData = GameInstance.GetTransactionSystem(this.GetGameInstance()).GetItemData(owner, itemID);
  if !IsDefined(player) || !IsDefined(itemData) || ItemID.HasFlag(itemID, gameEItemIDFlag.Preview) {
    wrappedMethod(owner, itemID);
    return;
  };
  tier = RPGManager.INE_GetInevitableTier(itemData);
  player.INE_ApplyInevitableUpgradeState(itemData, tier);
  wrappedMethod(owner, itemID);

  // Re-fetch: the vanilla transaction may have replaced/invalidated itemData.
  afterData = GameInstance.GetTransactionSystem(this.GetGameInstance()).GetItemData(owner, itemID);
  if !IsDefined(afterData) {
    return;
  };
  nativeAfter = afterData.GetStatValueByType(gamedataStatType.WasItemUpgraded);
  if nativeAfter > tier + 0.50 {
    player.INE_ApplyInevitableUpgradeState(afterData, MinF(tier + 1.00, 10.00));
  };
}

// Prepare an old item before the screen checks the maximum tier or temporarily
// increments the upgrade counter to draw its right-hand comparison tooltip.
@wrapMethod(UpgradingScreenController)
private final func UpdateItemPreviewPanel(const selectedItem: script_ref<InventoryItemData>) -> Void {
  let itemData: wref<gameItemData> = InventoryItemData.GetGameItemData(selectedItem);
  let player: ref<PlayerPuppet>;
  if IsDefined(itemData) && ItemID.GetTDBID(itemData.GetID()) == t"Items.Inevitable" {
    player = GetPlayer(this.m_Game);
    if IsDefined(player) {
      player.INE_EnsureInevitableUpgradeState(itemData);
    };
  };
  wrappedMethod(selectedItem);
}
