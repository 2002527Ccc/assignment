# 验证结果

## 已执行

- 唯一基础R1b ZIP安全解包、全运行源码审查，未从旧R1/R1c代码覆盖基础。
- 六个完整保护文件逐字节哈希相同；原controller除一个可选移交判断外相同；new/start/stop/tick核心方法源码哈希相同。CooldownBase仍1.0，完整TweakXL YAML未变。
- 实际LuaJIT 2.1/Lua 5.1解析11个运行Lua文件，通过。
- 35个原有R1行为用例、48个新增V2行为用例通过；另有实际V2入口集成检查，验证point换算、宿主范围、独立热键及观察器只注册一次。它们执行交付的实际Lua模块，依赖由mock提供。
- 5个.reds由官方REDscript真实parser解析，通过。工具源及固定提交/Cargo.lock保留。
- 新增接口对照公开NativeDB标注2.5的RTTI、Codeware源码声明；结果见API_DECLARATION_RESULTS.txt。类型/参数/字段来源有依据，未使用猜测的SetColorGrading一类接口。
- 新代码静态范围检查：无SetTimeDilation、原始生命/防御modifier、核心运行旗标或全局TweakDB写入；自身OS池/状态有显式排除。
- 最终ZIP路径、CRC、文件字节与SHA256清单检查由tools/package.py执行，实际打包结果随ZIP另存。

## 不应混淆的结果

- 用户已实机验证的是R1b的减速、扣血、启停。该结果保留，不冒充本环境执行。
- **本环境没有Cyberpunk2077.exe、原版final.redscripts或游戏编译/运行环境。2.0真实REDscript编译、TweakXL运行加载、游戏内新功能全部未执行。**
- RTTI有真实方法签名但不含全部方法体、时序或TweakDB flat值。声明核对与parser都不等于游戏链接/类型编译。
- mock池变化同步应用；实际引擎StatPool请求队列、Bolt检测先后和视觉资源绑定必须实机确认。
- 原生ICooldownSystem/私有timer、原生再生等待阶段未完整覆盖；不把“没有异常”或“没识别出状态”计成通过。
- Finale/Bolt、双持、蓝滤镜具体通道和第三方MOD组合没有在本环境验证。

## 复跑

```
python -m pip install -r tools/requirements-dev.txt
python tools/validate.py
```

需要lupa的luajit21后端。若设REDS_CHECK为实际parser驱动，会执行.reds语法解析；未设置时明确报告未运行，不伪造通过。驱动源码在tools/reds-parser，官方源码提交已锁定。

接口复核（先获取API_AND_SOURCES列出的公开参考仓库）：

```
python tools/check_api.py <NativeDB仓库目录> <Codeware仓库目录>
```

全编译应在本机2.5冷启动游戏并检查最新redscript日志。API错误时按模块隔离，禁止为通过编译而删除断言或修改已验证核心。
