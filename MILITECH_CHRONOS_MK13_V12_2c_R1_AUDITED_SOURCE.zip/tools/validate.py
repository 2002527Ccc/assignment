"""Offline checks, NOT a substitute for REDscript type compilation or game tests.
Development prerequisites: Python 3, PyYAML, lupa. Optional REDS_CHECK env var.
"""
import os, pathlib, subprocess, sys
import yaml
from lupa import LuaRuntime
ROOT = pathlib.Path(__file__).resolve().parents[1]
MOD = ROOT / 'bin/x64/plugins/cyber_engine_tweaks/mods/MilitechChronosMK13'
lua = LuaRuntime(unpack_returned_tuples=True)
lua.globals().package.path = str(MOD / '?.lua') + ';' + str(MOD / '?/init.lua')
for file in sorted(MOD.rglob('*.lua')):
    load = lua.eval('function(s,n) local f,e=load(s,n); assert(f,e); return true end')
    load(file.read_text(), str(file.relative_to(ROOT)))
    print('LUA PARSE PASS', file.relative_to(ROOT), flush=True)
count = lua.execute((ROOT / 'tools/tests/runtime_spec.lua').read_text())
print(f'{count} offline Lua behavior tests PASS', flush=True)
class Loader(yaml.SafeLoader):
    pass
for tag in ('!remove-all', '!append-from', '!append'):
    Loader.add_constructor(tag, lambda loader,node: {'operation':node.tag,'value':loader.construct_scalar(node)})
records = yaml.load((ROOT / 'r6/tweaks/chronos/chronos_mk13.yaml').read_text(), Loader=Loader)
allowed = ('Items.MilitechChronosMk13', 'Variants.Chronos101', 'Chronos.')
assert all(k in allowed[:2] or k.startswith(allowed[2]) for k in records), 'Global record write'
item = records['Items.MilitechChronosMk13']
values = {v['statType']: v['value'] for v in item['statModifiers']}
for key, value in {'TimeDilationSandevistanDuration':120, 'TimeDilationSandevistanRechargeDuration':1,
                   'TimeDilationSandevistanTimeScale':0.4, 'TimeDilationSandevistanEnterCost':0,
                   'SandevistanKillRechargeValue':0, 'HasSandevistanTier3':1}.items():
    assert values['BaseStats.'+key] == value, key
assert records['Variants.Chronos101']['statModifiers'][0]['value'] == 101
assert all(isinstance(v,dict) and 'operation' in v for v in item['OnEquip'])
assert records['Chronos.RangedHitPrereq']['pipelineType']=='Damage'
assert records['Chronos.RangedHitPrereq']['pipelineStage']=='Process'
assert not list(ROOT.rglob('*.archive')), 'Unexpected archive asset'
print('YAML structural/design invariants PASS (TweakXL runtime loading NOT tested)', flush=True)
checker = os.environ.get('REDS_CHECK')
if checker:
    subprocess.run([checker,*map(str,sorted((ROOT/'r6/scripts').glob('*.reds')))],check=True)
else:
    print('REDscript parser NOT RUN: set REDS_CHECK to a real parser executable')
print('Game 2.5 compilation, TweakXL load and in-game tests: NOT RUN')
