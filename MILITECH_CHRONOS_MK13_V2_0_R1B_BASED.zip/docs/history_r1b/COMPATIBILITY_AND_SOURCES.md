# 兼容性与证据来源

## 兼容边界

|组件|本次处理|兼容验证|
|---|---|---|
|Finale 终曲|不读写其记录/黑墙/穿透/Bolt函数；可选技术路径以Tech evolution和枪械类型识别|未提供该MOD，未实机；tech默认关闭|
|Inevitable 在劫 / Fate 命运|不修改它们的文件、记录和方法|未提供、未实测|
|Kerenzikov XMOD2|不接管Kerenzikov状态机或改公共CD|标签补偿可能遇到自定义时钟，需对照；未实测|
|Expanded Dual Wielding|不包装武器装备事件，不改武器全局stat|可选技术路径只处理ActiveWeapon，不能承诺两手覆盖；未实测|
|RED4ext / TweakXL / Codeware / CET|使用公开框架接口，依赖适配2.5的版本|没有游戏引擎运行验证|
|其他Sandevistan|独立装备和运行态门控；无原生PSM方法replacement、无全局视觉/ChargeTime修改|源码范围核查通过，实机未测|
|其他冷却修复MOD|不用快照还原，直接观测自然进度|修改原生rate来补时缓的MOD无法无歧义自动识别；见COVERAGE|
|其他视觉MOD|本版不发送猜测的通用VFX stop事件，也不写公共调色/相机记录|无蓝滤镜移除能力，未声称视觉修复已完成|

不捆绑/修改上述第三方MOD。结构上减少冲突不是“兼容性已通过”的证明。

## 实际读取的参考

精确提交见 `reference-commits.json`。

- RED4ext.SDK：<https://github.com/WopsS/RED4ext.SDK/commit/5246e659d783e5834cc08a90e56c8932c9ed3449>，提交说明 **Update types for patch 2.5 (#232)**。用于核对StatType、StatPoolType、WeaponEvolution、ItemType、PSM枚举和StatsObjectID/StatPoolModifier的原生结构。它不包含全部游戏脚本方法体和TweakDB实际flat值。
- REDscript：<https://github.com/jac3km4/redscript/tree/0c625df7784fea5e8078ee107a2b7ef2a580100e>，官方解析器1.0.0-preview.22。构建独立小驱动，实际解析了输入及输出.reds。只运行parser，不伪造缺失的游戏符号来制造“编译通过”。该解析器版本不同于本机未知的redscript稳定版，游戏安装编译仍是必要门槛。
- TweakXL：<https://github.com/psiberx/cp2077-tweak-xl/tree/3875f1debedefd080f471b3db9b929566137eb88>。读取YAML mutation处理、LocKey转换、ExtraFlats与InheritanceMap。证实不能混用数组赋值和mutation；已定位Nano-plating inline3/4/5继承、Apogee专属RestoreStatPoolOnKillEffector继承。**InheritanceMap不是完整flat dump，也不自动证明所有2.5记录值。**
- Codeware：<https://github.com/psiberx/cp2077-codeware/tree/decce71323d6f6183cf78143882032a3c70aac9e>，核对本地化Provider/Package接口及usingPointValues字段导出。
- CET：<https://github.com/maximegmd/CyberEngineTweaks/tree/b160d68cf923f2535cb3a6ebe006de86ef21e359>，LuaVM_Hooks.cpp中的帧delta来自std::chrono，支持用onUpdate delta作为现实时间来源；核对TweakDBID构造、比较和表示。
- NativeDB旧参考：<https://github.com/striderxfossility/NativeDB/tree/8f13e59e5007d97f3d105b8959bbe1bbbe9992a2>。仓库最后提交为2021年，仅用于确认传统API调用模式、StatusEffectHelper与ModifyAttackEffector调用结构；**不是2.5源码，不能证明新版本脚本签名仍完全一致**。

当前网络策略不允许codeberg.org，读取较新反编译脚本来源的请求被代理拒绝。本任务没有绕过网络限制，也没有更改现有云环境allowlist。即使取得较新源码，真实类型编译仍需目标游戏bundle或等价原版符号。
