"""Audit declared interfaces against the public 2.5-labelled RTTI and Codeware sources.
This does not link/compile game scripts. Arguments: NativeDB checkout, Codeware checkout.
"""
import json,pathlib,sys
native=pathlib.Path(sys.argv[1]);codeware=pathlib.Path(sys.argv[2])
rows=json.loads((native/'src/assets/reddump/classes.json').read_text())
classes={r['b']:r for r in rows}
checks={
 'EngineTime':['ToFloat'],
 'gamedataTweakDBRecord':['GetID'],
 'gameStatPoolsSystem':['IsStatPoolModificationDelayed','ToPercentage','GetStatPoolMaxPointValue'],
 'gameStatusEffectSystem':['GetAppliedEffects','SetStatusEffectRemainingDuration'],
 'gameStatusEffect':['GetRecord','GetRemainingDuration','GetLastApplicationSimTimestamp','GetStackCount'],
 'gamedataStatusEffect_Record':['IsAffectedByTimeDilationPlayer','GameplayTags','Duration','VFX'],
 'gamedataStatModifierGroup_Record':['StatModifiers','RelatedModifierGroups'],
 'gamedataStatModifier_Record':['StatType'],
 'gamedataCombinedStatModifier_Record':['RefStat'],
 'gamedataStatusEffectFX_Record':['Name'],
 'gamedataTweakDBInterface':['GetStatusEffectRecord'],
 'gamehelperGameObjectEffectHelper':['StartEffectEvent','StopEffectEvent'],
 'gameObject':['StartStatusEffectVFX'],
 'SandevistanEvents':['OnExit','OnForcedExit'],
 'PlayerPuppet':['OnDetach'],
}
count=0
for cls,methods in checks.items():
 for method in methods:
  f=next((f for f in classes[cls].get('f',[]) if f.get('b',f['a'].split(';')[0])==method),None)
  assert f is not None,(cls,method)
  print('RTTI CONFIRMED',cls+'.'+method,json.dumps({'return':f.get('c'),'params':f.get('e',[]),'flags':f['d']},ensure_ascii=False))
  count+=1
fields={
 'worldEffect':['events','trackRoot'], 'effectTrackGroup':['tracks'], 'effectTrack':['items'],
 'entEffectSpawnerComponent':['effectDescs'], 'entEffectDesc':['effectName','effect'],
}
for cls,names in fields.items():
 available={r['b'] for r in classes[cls].get('e',[])}
 for name in names:assert name in available,(cls,name)
 print('RTTI FIELDS CONFIRMED',cls,','.join(names))
for cls in ['effectTrackItemColorGrade','effectTrackItemColorGradeV2']:
 assert cls in classes;print('RTTI CLASS CONFIRMED',cls)
requirements={
 'scripts/Entity/Entity.reds':['GetComponents() -> array<ref<IComponent>>'],
 'scripts/Depot/ResourceReference.reds':['GetPath(self: script_ref<ResourceAsyncRef>) -> ResRef','IsEmpty(self: script_ref<ResourceAsyncRef>) -> Bool'],
 'scripts/Depot/ResourceDepot.reds':['LoadResource(path: ResRef) -> ref<ResourceToken>','GetResourceDepot() -> ref<ResourceDepot>'],
 'scripts/Depot/ResourceToken.reds':['GetResource() -> ref<CResource>','IsLoaded() -> Bool','IsFailed() -> Bool'],
 'scripts/Base/Imports/worldEffect.reds':['events: array<ref<effectTrackItem>>','trackRoot: ref<effectTrackGroup>'],
 'scripts/Base/Imports/effectTrackGroup.reds':['tracks: array<ref<effectTrackBase>>'],
 'scripts/Base/Imports/effectTrack.reds':['items: array<ref<effectTrackItem>>'],
 'scripts/Base/Imports/entEffectSpawnerComponent.reds':['effectDescs: array<ref<entEffectDesc>>'],
 'scripts/Base/Imports/entEffectDesc.reds':['effectName: CName','effect: ResourceAsyncRef'],
}
for file,patterns in requirements.items():
 text=(codeware/file).read_text()
 for p in patterns:assert p in text,(file,p)
 print('CODEWARE DECLARATIONS CONFIRMED',file)
print(f'{count} native/script method declarations checked; field/class/Codeware declarations checked.')
print('These are declaration checks, not game compilation, function-body verification, or playtests.')
