local Timing = require('modules/timing')
local Controller = require('modules/controller')
local tests, count = {}, 0
local function near(a,b) assert(math.abs(a-b)<0.00001, tostring(a)..' != '..tostring(b)) end
local function test(name,fn) tests[#tests+1]={name,fn} end
local function p(value, rate, enabled) return {value=value,rate=rate or 10,enabled=enabled~=false,decaying=false,points=false,limit=100} end
local function fixture(tech)
 local state={v={id=1},run=true,paused=false,hp=100,max=100,mods={},logs={},pool={},effects={},weapon=nil,requests={}}
 local api={}
 api.log=function(s) state.logs[#state.logs+1]=s end
 api.player=function() return state.v end
 api.sameOwner=function(a,b) return a.id==b.id end
 api.running=function() return state.run and state.hp>0 end
 api.suspended=function() return state.paused end
 api.arm=function(v,active) state.armed=active end
 api.makeModifier=function(n,v) return {name=n,value=v} end
 api.addModifier=function(v,h) assert(not state.mods[h]);state.mods[h]=v.id end
 api.removeModifier=function(v,h) state.mods[h]=nil;return true end
 api.drain=function(v,dt) state.hp=math.max(0,state.hp-state.max*dt/13) end
 api.pool=function(v,k)
  local src=state.pool[tostring(v.id)..k];if not src then return nil end
  local cp={};for a,b in pairs(src) do cp[a]=b end;return cp
 end
 api.changePool=function(v,k,a)
  local key=tostring(v.id)..k;state.pool[key].value=state.pool[key].value+a
  state.requests[#state.requests+1]={key=key,value=a}
 end
 api.cooldowns=function() return state.effects end
 api.setDuration=function(v,id,t) state.duration={id=id,t=t};return true end
 api.techWeapon=function() return state.weapon end
 local c=Controller.new(api,{pools={'HealingItemsCharges'},tech=tech,debug=true})
 return c,state,api
end
local function modCount(s) local n=0;for _ in pairs(s.mods) do n=n+1 end;return n end

test('40% pool progress receives precisely missing 60%',function() near(Timing.pool(p(10),p(10.4),0.1),0.6) end)
test('real-time pool receives zero correction',function() near(Timing.pool(p(10),p(11),0.1),0) end)
test('faster foreign pool receives zero correction',function() near(Timing.pool(p(10),p(12.5),0.1),0) end)
test('charge consumption is not regeneration',function() near(Timing.pool(p(10),p(1),0.1),0) end)
test('regen delay receives no premature charge',function() near(Timing.pool(p(10),p(10),0.1),0) end)
test('partial interval regeneration is bounded',function() near(Timing.pool(p(10),p(10.1),0.1),0.15) end)
test('pool caps at native rangeEnd',function() near(Timing.pool(p(99),p(99.4),0.2),0.6) end)
test('pool disabling is respected',function() near(Timing.pool(p(10),p(10.4,10,false),0.1),0) end)
test('point-value pools not assumed to be percent',function() local a=p(10.4);a.points=true;near(Timing.pool(p(10),a,0.1),0) end)
test('active decay skips regeneration compensation',function() local a=p(10.4);a.decaying=true;near(Timing.pool(p(10),a,0.1),0) end)
test('changed native rate rebases instead of restoring stale value',function() near(Timing.pool(p(10),p(10.4,20),0.1),0) end)
test('long frames invalidate cooldown observations',function() near(Timing.pool(p(10),p(14),1),0) end)
test('new pool is only sampled',function() near(Timing.pool(nil,p(10),0.1),0) end)
test('40% duration receives missing 60%',function() near(Timing.status({token=1,remaining=10},{token=1,remaining=9.96},0.1),0.06) end)
test('real-time duration not shortened',function() near(Timing.status({token=1,remaining=10},{token=1,remaining=9.9},0.1),0) end)
test('reapplied duration token rebases',function() near(Timing.status({token=1,remaining=10},{token=2,remaining=9.96},0.1),0) end)
test('extended duration rebases',function() near(Timing.status({token=1,remaining=10},{token=1,remaining=12},0.1),0) end)
test('external large duration jump is not multiplied',function() near(Timing.status({token=1,remaining=10},{token=1,remaining=5},0.1),0) end)
test('expiry does not create infinite zero-duration effect',function() near(Timing.status({token=1,remaining=.02},{token=1,remaining=.01},0.1),.009) end)
test('activation frame not billed before activation',function() local c,s=fixture();c:tick(.1);near(s.hp,100);assert(modCount(s)==2) end)
test('one real second drains 1/13 maximum HP',function() local c,s=fixture();c:tick(0);c:tick(1);near(s.hp,100-100/13) end)
test('max-health change affects next debit',function() local c,s=fixture();c:tick(0);s.max=260;s.hp=260;c:tick(1);near(s.hp,240) end)
test('drain can kill; no low-health shutdown',function() local c,s=fixture();c:tick(0);s.hp=1;c:tick(.2);near(s.hp,0);c:tick(.01);assert(not c.active and modCount(s)==0) end)
test('long active frame still incurs real-time health debit',function() local c,s=fixture();c:tick(0);c:tick(2);near(s.hp,100-200/13) end)
test('manual stop removes both modifiers and stops drain',function() local c,s=fixture();c:tick(0);assert(s.armed);s.run=false;c:tick(.1);near(s.hp,100);assert(modCount(s)==0 and not s.armed) end)
test('pause clears active benefits and costs',function() local c,s=fixture();c:tick(0);s.paused=true;c:tick(10);near(s.hp,100);assert(modCount(s)==0) end)
test('owner replacement cleans old handles',function() local c,s=fixture();c:tick(0);s.v={id=2};c:tick(0);assert(modCount(s)==2);for _,id in pairs(s.mods) do assert(id==2) end end)
test('100 reactivations never stack modifiers',function() local c,s=fixture();for i=1,100 do s.run=true;c:tick(0);assert(modCount(s)==2);s.run=false;c:tick(0);assert(modCount(s)==0) end end)
test('null player triggers cleanup',function() local c,s=fixture();c:tick(0);s.v=nil;c:tick(.1);assert(modCount(s)==0 and not c.active) end)
test('partial attach failure retains handles for cleanup',function() local c,s,a=fixture();local n=0;a.addModifier=function(v,h) n=n+1;if n==2 then error('second modifier add failed') end;s.mods[h]=v.id end;assert(not pcall(function() c:tick(0) end));c:stop('failure');assert(modCount(s)==0) end)
test('failed removal retained and retried',function() local c,s,a=fixture();c:tick(0);local original=a.removeModifier;a.removeModifier=function() return false end;c:stop('failure');assert(#c.removals==2);a.removeModifier=original;c:stop('retry');assert(#c.removals==0 and modCount(s)==0) end)
test('new weapon rebases and old weapon is never restored',function() local c,s=fixture(true);s.weapon={id=11};s.pool['11WeaponCharge']=p(10);c:tick(0);c:tick(.1);s.pool['11WeaponCharge'].value=10.4;c:tick(.1);near(s.pool['11WeaponCharge'].value,11);s.weapon={id=12};s.pool['12WeaponCharge']=p(20);c:tick(.1);near(s.pool['11WeaponCharge'].value,11);near(s.pool['12WeaponCharge'].value,20);c:stop('exit');assert(#s.requests==1) end)
test('own OS reserve never receives a compensation request',function() local c,s=fixture();s.pool['1SandevistanCharge']=p(1);c:tick(0);c:tick(.1);s.pool['1SandevistanCharge'].value=2;c:tick(.1);for _,q in ipairs(s.requests) do assert(not q.key:find('Sandevistan')) end end)
test('only measured cooldowns corrected; no snapshot rate write',function() local c,s=fixture();s.pool['1HealingItemsCharges']=p(10);c:tick(0);c:tick(.1);s.pool['1HealingItemsCharges'].value=10.4;c:tick(.1);near(s.pool['1HealingItemsCharges'].value,11);near(s.pool['1HealingItemsCharges'].rate,10);c:stop('done');near(s.pool['1HealingItemsCharges'].rate,10) end)
test('optional cooldown API failure preserves core drain and defense',function() local c,s,a=fixture();a.cooldowns=function() error('unsupported optional API') end;c:tick(0);c:tick(.1);assert(c.statusesFailed and c.active and s.armed and modCount(s)==2);c:tick(1);near(s.hp,100-110/13) end)

for _,t in ipairs(tests) do t[2]();count=count+1;print('PASS '..t[1]) end
return count
