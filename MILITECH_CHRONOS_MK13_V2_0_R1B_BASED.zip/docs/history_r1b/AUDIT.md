# 审查与实现说明

## 输入审查

V12.2c为起点，V12.2b只用于差异对照。输入c包共13个文件，其中REDscript 4、YAML 1、Lua 1、archive **0**；其余为说明及PNG。b到c主要是EntityID→StatsObjectID显式转换、数组操作、状态数组类型改动，未解决完整生命周期和API可用性问题。

对四份旧REDscript进行了真实解析器检查：均可解析。**因此不能把本次问题归结为已知语法错误仍然存在，也不能据此认定类型正确。** 原包的“未编译候选”标记是准确的。

## 按模块修复

### 原生启停与物品：chronos_mk13.yaml

- 独立ID不变，克隆Apogee物品；所有写入目标仅在Chronos命名空间或独立自定义物品/容量变体下。
- 加入原包覆盖statModifiers时未保留的 `HasSandevistanTier3` 标志，以供原生高级储备/启停逻辑判断。此处是配置修正，尚未实机证明二次启动BUG已解决。
- 不再用空自定义包代替全部通用OS逻辑：用TweakXL `!remove-all` / `!append-from` 从 `Items.SandevistanBase.OnEquip`、`.OnAttach` 复用通用原生包，排除Apogee专属击杀/战斗包，再加入独立UI与格挡包。
- 保留Duration=120、RechargeDuration=1、EnterCost=0、TimeScale=0.4、CooldownBase=0、KillRecharge=0、独立101容量变体。
- 没有手写SandevistanCharge池，不重复施加时缓，不接管启停状态机，不篡改公共充能记录。
- 当前仍需原版2.5数据验证通用包具体内容、容量变体前置条件、派生充能率/延迟与边界。120秒储备意味着100/120≈0.833333个百分点/现实秒的运行消耗，1秒全充意味着100个百分点/现实秒的恢复；两者是不同阶段的速率，设计上并非必然冲突。不能在未看到原生公式时断言实际实现已满足这些速率。

### 类型边界：ChronosTemporalCompensation.reds

原文件从多处SandevistanEvents wrapper改成静态 `ChronosBridge`：

- StatsSystem与StatPoolsSystem统一用 `Cast<StatsObjectID>(owner.GetEntityID())`；StatusEffectSystem仍传EntityID，未混淆两个系统。
- 正确使用 `StatusEffectHelper.GetAppliedEffectsWithTag`，而非把脚本Helper方法当成StatusEffectSystem实例方法。
- 原生GetModifier的out参数在REDscript内处理，再向Lua返回结构体，减少Lua对out参数/强类型ID的错误推断。
- 装备判断用ItemID.GetTDBID精确比较，不依赖Lua中ItemID内部表示。
- 运行条件联合独立装备、原生Sandevistan PSM状态、原生时间键、可活动场景、存活和Health>0；暂停/菜单另行处理。
- 玩家非persistent布尔字段只表示CET控制器已成功附加，缺失或故障的CET控制器不会单独留下格挡收益。

### 生命与减伤：controller.lua / init.lua

- CET的真实帧间隔进入控制器；原始生命扣除走原生Health池的**最大值百分比**接口，`-100*dt/13`个百分点。无需通过错误的raw-HP读取和猜测ForceKill记录。
- 不走攻击管线，因此不乘护甲/减伤；不设低血停机，不加安全生命值下限。普通治疗仍由原生系统处理。
- 删除“超过0.75秒就免费跳过扣血”的逻辑；长活动帧仍扣对应真实时间。长帧仅重置不可靠的冷却采样。
- 单一控制器；每次启停只管理自己创建的两个Additive modifier（+28/+7），不改其他义体公共记录。
- 玩家换对象、暂停、原生退出/强制退出观察器、OnDetach、CET shutdown负责清理；普通轮询提供下一帧清理兜底。观察器只在onInit注册一次。
- 添加前先保存modifier句柄，部分添加失败也能回滚；移除失败保留句柄重试，禁止在未清完旧句柄时再次附加。
- 核心运行错误停止控制器并撤销收益；可选冷却/技术模块错误单独停用并报告，不中断核心生命损耗。

### 完全格挡：ChronosDeflection.reds

- 独立ModifyAttackEffector，不修改原版NanoTechPlatesEffector。
- 使用原版Nano镀层inline3/4/5的独立克隆作为Process/Damage/HitReceived、Ranged+Ranged筛选；源码再核验攻击类型和武器类型。
- 原包 `Prereqs.AttackType` / `Prereqs.WeaponType` 缺少可确认的类型记录依据；改成直接克隆已可定位的原版条件记录，不猜type ID。
- 仅RepeatedAction进行一次抽签，移除ActionOn二次入口；同一命中对象去重，目标必须为装备者。
- 动态读取TechnicalAbility：0.13 + tech*0.001，tech=20时0.15。成功只把当前攻击伤害乘0；无冲刺强化、次数限制或投射物飞行修改。
- 伤害乘0与普通减伤乘数在算术上可交换；不重跑伤害系统、不产生治疗请求。**实际2.5 Damage Process顺序、其他伤害MOD回调仍需实测。**

### 冷却：timing.lua / controller.lua

- 删除旧整池 `RequestSettingModifier` 快照、乘2.5、退出还原路径，避免覆盖其他MOD的新属性。
- 测量自然进度，补足相对现实时间不足的部分；最多增加已观测自然进度的1.5倍，只消除Chronos的0.4时标份额。
- 未开始恢复、仍在Decay、刚使用导致值下降、速率改变、单位为point、读档长间隔时不凭空补充。
- 状态冷却按实例最后施加时间戳区分，刷新/延长不沿用旧样本；已现实时间倒计时不再缩短。排除SandevistanCooldown，自身SandevistanCharge根本不在列表。
- 首次采样只建基线；近到期duration保留0.001原生秒以免0被解释成无限持续。不是“刚开启就把全部冷却缩短60%”。
- 固定四个玩家池和当前带标签状态以10Hz处理，没有遍历全TweakDB或全部义体。仅可选技术武器采用每帧小池采样。

### 技术与视觉

- 删除旧ChargeTime乘0.4和武器启停wrapper，不再受该修改器的最小值夹取、叠加及旧武器移除失败影响。
- 可选实现只补偿当前原生WeaponCharge池的已观察进度；严格检查Tech evolution及枪械itemType白名单，排除义体手臂、单分子线和载具武器。无需武器记录改写，也无换枪属性遗留。
- **由于无法证明额外池请求与2.5 Bolt检测顺序一致，此技术模块默认关闭，不计为完成。** 不修改Bolt窗口/阈值记录不等于已经证明不影响Bolt。
- 删除旧视觉文件中猜测time_dilation_vfx名称的停止调用，没有把相机时间曲线误当成屏幕调色。**专属蓝滤镜移除未实现**，没有用全局滤镜覆盖代替。

### UI与包内容

替换无可靠依据的 `Items.AdvancedSandevistanAbilityUIData` 为独立UI记录，用Codeware本地化提供名称和如实描述；不宣称全义体/技术/蓝滤镜已完成。参考PNG保留在assets-source；未伪造.archive或借用外部视觉资产。
