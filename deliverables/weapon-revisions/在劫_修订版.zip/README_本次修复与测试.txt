﻿在劫 Inevitable — 战斗爆头眩晕前置条件修复（完整 Vortex 测试版）

【本次确定修复】
日志中报错：Items.INE_CombatHeadPrereq 无法克隆 Prereqs.IsHitTargetAlive（不存在）。
现在该记录从已知存在的 Prereqs.ProcessHitTriggered 派生，保留原本的
Inevitable.INE_CombatHeadPrereq 自定义判断和 PostProcess 阶段。
该新基类在公开的游戏 tweak 示例中使用过，但此包尚未经过你当前游戏实测。

【按原设计保留，未重新实现】
• 任意有效近战/投掷命中：目标受后续直接武器伤害 +10%，持续10秒（命中刷新，不叠层）。
• 非战斗/潜行爆头：原生 Stun 5秒，成功控制后避免本次命中立刻强制警觉；不影响正常目击与视线。
• 战斗爆头：自定义 Stun 3秒，并带3秒控制免疫；身体命中不眩晕。
• 原版 Stinger 外观；独立物品 ID Items.Inevitable；两投掷插件槽及阶级升级代码不变。

【安装】
1. 彻底退出游戏；在 Vortex 中禁用旧版在劫和所有其他在劫测试版本。
2. Install From File 安装本 ZIP，启用后部署。无需额外叠加原版在劫。
3. 保留 RED4ext、ArchiveXL、TweakXL、redscript 及所需前置。
4. 进游戏可使用原有在劫。如果状态异常，先备份存档，再用 CET 新领取一把用于测试：
   Game.AddToInventory("Items.Inevitable", 1)
5. 首次运行后查看 red4ext/plugins/TweakXL 的最新日志：
   不应再出现 Items.INE_CombatHeadPrereq 的 cannot clone 错误，
   也不应再出现 Items.INE_CombatStunEffector.prereqRecord 无效引用警告。
   如果仍出现，请将最新日志上传检查，别在同一项目里同时部署新旧 YAML。

【技能测试】
A. 找一个能承受一刀、可以观察状态的敌人，先以非爆头命中，不应眩晕。
B. 未进入战斗时爆头，观察是否眩晕约5秒。
C. 完全进入战斗后，对另一名未免疫的敌人爆头，观察是否眩晕约3秒。
D. 受击后的10秒内，用普通直接伤害攻击同一目标，比较后续伤害。
E. 检查投掷与近战均能触发，升级和两个插件槽保持原状。

【限制】
已做 ZIP 完整性、TweakXL YAML 解析、静态目标参数核对和逐文件比较。
没有在你的本机游戏中运行或实测；实际触发时机、青牙原生潜行眩晕依赖、免疫与伤害
仍需实机确认。此版不能承诺所有技能已百分之百成功。
