# MILITECH MK.13 — CHRONOS · 2.0（R1b基线开发候选）

**唯一基础是用户上传、已实机验证启停/减速/扣血正常的R1b。2.0的三项新模块尚未在游戏中编译或实测，不能把R1b的验证结果延伸为2.0已验证。**

本包是完整Vortex安装结构，含原R1b核心、独立V2扩展、全部源码、离线测试、修改报告和实机步骤。

## 保留的R1b机制

三份原REDscript、原TweakXL YAML、原CET init.lua、原timing.lua逐字节保持一致。核心controller的new/start/stop/tick保持原文；唯一改动是在旧可选冷却入口加移交判断，并在旧config启用移交，防止双重补偿。原生冷却基数仍为 **1.0**，没有回退为导致早期重复启动问题的0。减速、扣血、格挡/技术概率、减伤、容量、储备和充能配置均未修改。

## 新模块

- **技术武器**：独立WeaponCharge进度差额补偿，不改ChargeTime/min、Bolt窗口、武器记录或Finale源码。换枪/关闭/读档丢弃观察状态，无需还原武器modifier。
- **冷却**：四个原生玩家充能池；玩家当前冷却状态按标签、明确原生ID、Duration引用的冷却属性识别。先检查 `IsAffectedByTimeDilationPlayer`，仅补偿实际减慢的计时；不触碰SandevistanCharge及斯安威斯坦状态。
- **视觉**：从原版Sandevistan状态记录定位玩家效果资源，确有ColorGrade/ColorGradeV2相机调色轨才停止对应原生效果。没有猜测事件名，没有改公共LUT/相机时间曲线/缓存资源。能否命中本机实际蓝色滤镜路径仍需实机；不匹配会明确报告未解析。

默认三个开关均开启，在第二个CET目录的config.lua中独立设置，也能用CET热键逐项开关。首次验收建议先三项关闭对照R1b，再单独开启测试。

**覆盖限制：不能声称全义体CD已经100%覆盖。** 未暴露为StatusEffect/支持池的原生ICooldownSystem或私有Delay/TimeBank计时，以及原生恢复开始等待阶段，没有被擅自改写。详见 [实际覆盖与缺口](docs/COVERAGE.md)。Finale/Bolt和蓝滤镜实际表现也需要游戏测试。

## 文档与验证

- [修改前基线审查](docs/BASELINE_REVIEW.md)
- [逐模块修改报告](docs/MODIFICATION_REPORT.md)
- [具体冷却覆盖与限制](docs/COVERAGE.md)
- [开关、安装与回退](docs/INSTALL.md)
- [实机测试步骤](docs/TEST_PLAN.md)
- [验证结果与复跑](docs/VALIDATION.md)
- [接口与来源](docs/API_AND_SOURCES.md)

离线已通过：35个保留的R1行为用例、48个新增行为用例、实际V2入口集成检查；使用LuaJIT 2.1/Lua 5.1。5份REDscript通过真实解析器检查，11份运行Lua文件语法检查通过。不是游戏类型编译或实机证明。

CET获取（ID不变）：

```lua
Game.AddToInventory("Items.MilitechChronosMk13", 1)
```

安装前卸载/停用旧Chronos包，只部署本完整包；不要保留旧版重复脚本。框架沿用适配2.5的RED4ext/redscript/TweakXL/CET/Codeware，视觉查询还依赖Codeware的资源和组件接口。没有捆绑外部视觉MOD或新.archive。历史R1说明在docs/history_r1b，仅供追溯，本页及当前docs优先。
