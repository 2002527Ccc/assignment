# 2.0修改报告

## 基线和不变性

唯一基础：`MILITECH_CHRONOS_MK13_R1b_VANILLA_RESTART_FIX.zip`。R1b减速、生命损耗、重复启动的实测成功由用户确认；当前容器未复现实机。

`R1B_PROTECTED_HASHES.json`记录六个完整文件哈希：原三份REDscript、物品YAML、原CET init.lua、原timing.lua，全部逐字节未变。`R1B_CORE_METHOD_HASHES.json`记录原controller核心方法及整个原controller/config哈希，验证脚本能自动证明：

- controller只多一行 `if self.config.v2Features then return end`，位于**旧的可选updateCooldowns**入口；其他字节不变。
- 旧config只多一行 `v2Features = true`；原tech=false不变。
- new/start/stop/tick四个核心方法原文一致。
- Duration=120、TimeScale=0.4、Recharge=1、EnterCost=0、**CooldownBase=1**、格挡、减伤、生命成本和独立ID都不变。

该移交只关闭旧可选冷却补偿，避免两个控制器同时缩短相同timer，不是替换原生启停或R1b核心。即使新模块关闭/报错，R1b继续单独负责生命、防御、运行判定和启停。

## 目录和职责

原CET目录 `MilitechChronosMK13` 保留核心。新增 `MilitechChronosMK13V2` 单独注册其onUpdate及观察器，不覆盖原CET事件回调，也不重复扣血。

|新增文件|职责|
|---|---|
|V2/config.lua|三个独立开关、排除项、采样间隔、诊断参数|
|V2/modules/manager.lua|仅按R1b ControllerIsActive+IsRunning+非暂停门控新模块；故障隔离|
|V2/modules/progress.lua|纯进度差额数学；已现实时间的timer不额外加速|
|V2/modules/tech.lua|当前技术枪械WeaponCharge补偿；无武器stat modifier|
|V2/modules/cooldowns.lua|四个池、原生状态候选、标签/Duration属性匹配、自身OS排除|
|V2/modules/visual.lua|异步读取实际效果资源，确认调色轨后停止该玩家的对应效果|
|V2/init.lua|确认过类型的API适配、一次性观察器、诊断和独立热键|
|r6/scripts/ChronosV2Queries.reds|支持池单位/延迟及当前状态只读查询，无PSM wrapper|
|r6/scripts/ChronosV2VisualQueries.reds|独立的原生VFX资源/ColorGrade轨查询与效果生命周期调用|

## 技术武器

只使用R1b已存在的IsTechGun枪械白名单/Tech evolution判定。普通枪械、义体手臂、单分子线、载具武器不纳入。读取当前枪的原生WeaponCharge再生参数和自然进度，补足时缓造成的差额；不写ChargeTime、EffectiveChargeTime、min、Bolt阈值或窗口。

算法尊重启用、Decay、原生延迟、自然恢复是否已开始、当前速率及边界，速率/武器变化会重新采样。无快照还原，不会把旧武器属性恢复到过时数值。长帧只清新模块观察状态，不触碰R1b的扣血计时。

兼容Finale的依据是它作为Tech枪械且使用原生WeaponCharge时会自动纳入；没有改其黑墙、穿透、充能脚本或Bolt逻辑。**未取得Finale源码/未实机，因此不宣称它所有自定义路径及Bolt已兼容通过。**

## 冷却

原生2.5 StatusEffect_Record提供IsAffectedByTimeDilationPlayer，因此不再把所有标签timer一概视为减慢。GetAppliedEffects只读取当前玩家，不遍历全TweakDB。记录元数据按ID缓存，Duration关联组最多深度4，避免循环/每帧大扫描。

新增：明确原生冷却ID作为无标签补充；Duration引用Kerenzikov/SecondHeart/健康下降/闪避/进战等冷却属性时补充识别；状态时间戳和stack数变化重新采样；point单位池用原生ToPercentage统一到百分比，并检查IsStatPoolModificationDelayed。

差额至多为已观察自然进度的1.5倍，只消除Chronos的0.4时标份额；不会固定乘全部冷却2.5。已现实时间的状态、已有足够恢复进度的池不再加速。自身SandevistanCharge、Health、TimeBank禁止由V2写入；全部Sandevistan状态显式排除。

公开接口没有提供所有原生ICooldownSystem timer的剩余时间/可逆时标设置。没有通过“注册时永久affectedByTimeDilation=false”伪造全覆盖，也没有把未知Delay/TimeBank当成同一池。恢复开始等待阶段仍遵循原生延迟；不能宣称它也被完整校正。

## 视觉

不是停止猜测的time_dilation_vfx。执行路径为：

1. 读SandevistanPlayerBuff及CooldownedSandevistanPlayerBuff的真实VFX记录。
2. 匹配当前玩家EffectSpawner里的effectName，取实际资源路径。
3. 通过Codeware资源token异步只读加载，遍历worldEffect.events/trackRoot。
4. 仅确认存在effectTrackItemColorGrade或ColorGradeV2后，用原生StopEffectEvent终止该事件，交由原生效果生命周期释放其调色轨。
5. 记录被停止的事件；模块手动关闭且Chronos仍运行时只恢复这些事件。正常关机、死亡、读档、其他OS不重启它们。

不修改资源内容、公共LUT、相机时间曲线或第三方视觉MOD文件。**终止单位是包含调色轨的整个原生效果事件**，其中附属的原版模糊/粒子也可能一并停止；没有声称只编辑其中一个轨道。如果实际蓝滤镜由未列入这些记录的独立相机通道驱动，当前模块会报告未解析而非修改全局相机。异步首次加载可能有短暂入场闪色，待游戏检验。

## 未改变的内容

不修改R1b时间曲线、启动动作、充能池配置、状态应用/移除、基础生命/防御设计，不改其他Sandevistan或第三方MOD。原Localization也保持原文，其保守的未验收描述未被夸大为全功能已通过。
