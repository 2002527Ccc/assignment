local Progress=require('modules/progress')
local Tech=require('modules/tech')
local Cooldowns=require('modules/cooldowns')
local Visual=require('modules/visual')
local Manager=require('modules/manager')
local tests={}
local function test(n,f)tests[#tests+1]={n,f}end
local function near(a,b)assert(math.abs(a-b)<0.000001,tostring(a)..' ~= '..tostring(b))end
local function pool(v,r)return{value=v,rate=r or 10,limit=100,enabled=true,delayed=false,decaying=false}end
local function status(rem)return{id='x',key='x',name='BaseStatusEffect.KerenzikovCooldown',remaining=rem,stamp=1,stacks=1,affected=true,tagged=false}end
local function config()return{enabled={tech=true,cooldowns=true,visual=true},maxObservationGap=.5,sampleInterval=.05,pools={'HealingItemsCharges'},excludedPools={},excludedStatuses={},visualResolveTimeout=1}end
local function fixture()
 local s={player={id=1},active=true,weapon=nil,pools={},statuses={},changes={},durations={},logs={},stop={},restore={},targets={},tokens={},counts={}}
 local a={}
 a.player=function()return s.player end
 a.active=function(v)return s.active and v.id==s.player.id end
 a.same=function(x,y)return x.id==y.id end
 a.log=function(x)s.logs[#s.logs+1]=x end
 a.count=function(x)s.counts[x]=(s.counts[x]or 0)+1 end
 a.techWeapon=function()return s.weapon end
 a.pool=function(v,k)local p=s.pools[v.id..k];if not p then return nil end;local c={};for x,y in pairs(p)do c[x]=y end;return c end
 a.changePool=function(v,k,x)s.changes[#s.changes+1]={id=v.id,kind=k,x=x};s.pools[v.id..k].value=s.pools[v.id..k].value+x end
 a.statuses=function()return s.statuses end
 a.duration=function(v,id,x)s.durations[#s.durations+1]={id=id,x=x};return true end
 a.durationUsesCooldown=function()return false end
 a.visualTargets=function()return s.targets end
 a.loadResource=function(path)return s.tokens[path]end
 a.resourceState=function(t)return t.state end
 a.resourceHasGrade=function(t)return t.grade end
 a.stopVisual=function(v,n)s.stop[#s.stop+1]={owner=v.id,name=n}end
 a.restoreVisual=function(v,n)s.restore[#s.restore+1]={owner=v.id,name=n}end
 return a,s
end

test('pool correction fills 40-percent clock deficit only',function()near(Progress.pool(pool(10),pool(10.2),.05,.5),.3)end)
test('already-real-time pool is not accelerated',function()near(Progress.pool(pool(10),pool(10.5),.05,.5),0)end)
test('external faster progress is not accelerated',function()near(Progress.pool(pool(10),pool(11),.05,.5),0)end)
test('regen delay forbids extra progress',function()local x=pool(10.2);x.delayed=true;near(Progress.pool(pool(10),x,.05,.5),0)end)
test('decay forbids extra progress',function()local x=pool(10.2);x.decaying=true;near(Progress.pool(pool(10),x,.05,.5),0)end)
test('rate change rebases without snapshot restore',function()near(Progress.pool(pool(10),pool(10.2,20),.05,.5),0)end)
test('partial regen start does not skip delay',function()near(Progress.pool(pool(10),pool(10.1),.05,.5),.15)end)
test('native range cap is respected',function()near(Progress.pool(pool(99.5),pool(99.9),.1,.5),.1)end)
test('charge consumption is not cooldown elapsed time',function()near(Progress.pool(pool(10),pool(2),.05,.5),0)end)
test('long interval not used for rate inference',function()near(Progress.pool(pool(10),pool(12),1,.5),0)end)
test('nonfinite native rate is never sent to pool',function()near(Progress.pool(pool(10),pool(10.2,math.huge),.05,.5),0)end)
test('nonfinite native duration is never written',function()near(Progress.status(status(10),status(0/0),.05,.5),0)end)
test('real-time native status flag blocks correction',function()local x=status(9.98);x.affected=false;near(Progress.status(status(10),x,.05,.5),0)end)
test('slowed native status corrected to real time',function()near(Progress.status(status(10),status(9.98),.05,.5),.03)end)
test('real-time observed status not accelerated',function()near(Progress.status(status(10),status(9.95),.05,.5),0)end)
test('stack change rebases status',function()local x=status(9.98);x.stacks=2;near(Progress.status(status(10),x,.05,.5),0)end)
test('reapplication timestamp rebases status',function()local x=status(9.98);x.stamp=2;near(Progress.status(status(10),x,.05,.5),0)end)
test('foreign duration cut not multiplied',function()near(Progress.status(status(10),status(5),.05,.5),0)end)
test('expiry remains positive rather than infinite zero',function()near(Progress.status(status(.02),status(.01),.05,.5),.009)end)
test('technical gun alone receives weapon-pool credit',function()local a,s=fixture();s.weapon={id=2};s.pools['2WeaponCharge']=pool(10);local t=Tech.new(a,config());t:start(s.player);t:tick(s.player,.05);s.pools['2WeaponCharge'].value=10.2;t:tick(s.player,.05);near(s.pools['2WeaponCharge'].value,10.5);assert(#s.changes==1 and s.changes[1].id==2)end)
test('swap discards old weapon baseline',function()local a,s=fixture();s.weapon={id=2};s.pools['2WeaponCharge']=pool(10);local t=Tech.new(a,config());t:start(s.player);t:tick(s.player,.05);s.weapon={id=3};s.pools['3WeaponCharge']=pool(50);t:tick(s.player,.05);assert(#s.changes==0);near(s.pools['2WeaponCharge'].value,10)end)
test('ordinary gun/holster has no charge correction',function()local a,s=fixture();local t=Tech.new(a,config());t:start(s.player);t:tick(s.player,.05);assert(#s.changes==0)end)
test('tech stop retains no old weapon or modifier handle',function()local a,s=fixture();local t=Tech.new(a,config());s.weapon={id=2};s.pools['2WeaponCharge']=pool(10);t:start(s.player);t:tick(s.player,.05);t:stop();assert(not t.owner and not t.previous and not t.weapon)end)
test('explicit untagged native cooldown selected',function()local a,s=fixture();local c=Cooldowns.new(a,config());assert(c:classify(status(10)))end)
test('hashed unnamed candidate can use native ID match',function()local a,s=fixture();local c=Cooldowns.new(a,config());local x=status(10);x.name='unresolved';x.nativeCandidate=true;assert(c:classify(x))end)
test('duration-stat native cooldown selected',function()local a,s=fixture();a.durationUsesCooldown=function()return true end;local c=Cooldowns.new(a,config());local x=status(10);x.name='newNativeStatus';assert(c:classify(x))end)
test('unknown combat buff not treated as cooldown',function()local a,s=fixture();local c=Cooldowns.new(a,config());local x=status(10);x.name='DamageBonus';assert(not c:classify(x))end)
test('native non-dilated cooldown untouched',function()local a,s=fixture();local c=Cooldowns.new(a,config());local x=status(10);x.affected=false;assert(not c:classify(x))end)
test('own Sandy cooldown excluded even when tagged',function()local a,s=fixture();local c=Cooldowns.new(a,config());local x=status(10);x.name='BaseStatusEffect.SandevistanCooldown';x.tagged=true;assert(not c:classify(x))end)
test('own opaque ID excluded without relying on text',function()local a,s=fixture();local c=Cooldowns.new(a,config());local x=status(10);x.name='unknown';x.own=true;x.tagged=true;assert(not c:classify(x))end)
test('excluded status opt-out honored',function()local a,s=fixture();local cfg=config();cfg.excludedStatuses['BaseStatusEffect.KerenzikovCooldown']=true;local c=Cooldowns.new(a,cfg);assert(not c:classify(status(10)))end)
test('excluded pool opt-out honored',function()local a,s=fixture();local cfg=config();cfg.excludedPools.HealingItemsCharges=true;s.pools['1HealingItemsCharges']=pool(10);local c=Cooldowns.new(a,cfg);c:start(s.player);c:tick(s.player,.05);s.pools['1HealingItemsCharges'].value=10.2;c:tick(s.player,.05);assert(#s.changes==0)end)
test('Forbidden self-charge pool configuration rejected',function()local a,s=fixture();local cfg=config();cfg.pools={'SandevistanCharge'};local c=Cooldowns.new(a,cfg);c:start(s.player);assert(not pcall(function()c:tick(s.player,.05)end))end)
test('tagged status correction writes remaining time once',function()local a,s=fixture();local c=Cooldowns.new(a,config());c:start(s.player);s.statuses={status(10)};c:tick(s.player,.05);s.statuses={status(9.98)};c:tick(s.player,.05);assert(#s.durations==1);near(s.durations[1].x,9.95)end)
test('only verified grade-containing effect stopped',function()local a,s=fixture();s.targets={{name='nativeGrade',path='grade'},{name='nativeParticles',path='fx'}};s.tokens.grade={state='loaded',grade=true};s.tokens.fx={state='loaded',grade=false};local v=Visual.new(a,config());v:start(s.player);v:tick(s.player,.05);assert(#s.stop==1 and s.stop[1].name=='nativeGrade')end)
test('pending resource not guessed/stopped early',function()local a,s=fixture();s.targets={{name='nativeGrade',path='g'}};s.tokens.g={state='pending'};local v=Visual.new(a,config());v:start(s.player);v:tick(s.player,.05);assert(#s.stop==0);s.tokens.g={state='loaded',grade=true};v.pending[1].token=s.tokens.g;v:tick(s.player,.05);assert(#s.stop==1)end)
test('visual timeout does not change camera or any resource',function()local a,s=fixture();s.targets={{name='nativeGrade',path='g'}};s.tokens.g={state='pending'};local v=Visual.new(a,config());v:start(s.player);v:tick(s.player,2);assert(#s.stop==0 and #v.pending==0)end)
test('visual off while running restores exactly suppressed native effect',function()local a,s=fixture();s.targets={{name='nativeGrade',path='g'}};s.tokens.g={state='loaded',grade=true};local v=Visual.new(a,config());v:start(s.player);v:tick(s.player,.05);v:stop(true);assert(#s.restore==1 and s.restore[1].name=='nativeGrade')end)
test('OS exit/death does not restart blue grade',function()local a,s=fixture();s.targets={{name='nativeGrade',path='g'}};s.tokens.g={state='loaded',grade=true};local v=Visual.new(a,config());v:start(s.player);v:tick(s.player,.05);s.active=false;v:stop(true);assert(#s.restore==0)end)
test('reapplied native VFX gets resuppressed without rescanning',function()local a,s=fixture();s.targets={{name='nativeGrade',path='g'}};s.tokens.g={state='loaded',grade=true};local v=Visual.new(a,config());v:start(s.player);v:tick(s.player,.05);v:resuppress();assert(#s.stop==2)end)
test('unknown visual descriptors cause no VFX suppression',function()local a,s=fixture();local v=Visual.new(a,config());v:start(s.player);v:tick(s.player,.05);assert(#s.stop==0 and #s.logs==1)end)
local function dummy(counter,name,fail)
 return {start=function()counter[name..'Start']=(counter[name..'Start']or 0)+1;if fail then error('module failure')end end,
 tick=function()counter[name..'Tick']=(counter[name..'Tick']or 0)+1 end,
 stop=function(_,restore)counter[name..'Stop']=(counter[name..'Stop']or 0)+1;counter[name..'Restore']=restore end}
end
test('manager does nothing under another OS/inactive core',function()local a,s=fixture();s.active=false;local q={};local m=Manager.new(a,config(),{tech=dummy(q,'t')});m:tick(.05);assert(not q.tStart)end)
test('module startup failure isolated from others',function()local a,s=fixture();local q={};local m=Manager.new(a,config(),{tech=dummy(q,'t',true),cooldowns=dummy(q,'c')});m:tick(.05);m:tick(.05);assert(m.failed.tech and q.cTick==1 and q.tStop==1)end)
test('three module toggles are independent',function()local a,s=fixture();local q={};local m=Manager.new(a,config(),{tech=dummy(q,'t'),cooldowns=dummy(q,'c'),visual=dummy(q,'v')});m:tick(.05);m:setEnabled('tech',false);m:tick(.05);assert(q.tStop==1 and not q.tTick and q.cTick==1 and q.vTick==1)end)
test('100 reactivations have one cleanup per activation',function()local a,s=fixture();local q={};local m=Manager.new(a,config(),{tech=dummy(q,'t')});for i=1,100 do s.active=true;m:tick(.05);s.active=false;m:tick(.05)end;assert(q.tStart==100 and q.tStop==100)end)
test('owner/load change cleans previous module state',function()local a,s=fixture();local q={};local m=Manager.new(a,config(),{tech=dummy(q,'t')});m:tick(.05);s.player={id=2};m:tick(.05);assert(q.tStop==1 and q.tStart==2)end)
test('runtime config off cleans active module',function()local a,s=fixture();local q={};local cfg=config();local m=Manager.new(a,cfg,{tech=dummy(q,'t')});m:tick(.05);cfg.enabled.tech=false;m:tick(.05);assert(q.tStop==1 and not m.running.tech)end)
test('gap resets observations and restores active native visuals',function()local a,s=fixture();local q={};local m=Manager.new(a,config(),{visual=dummy(q,'v')});m:tick(.05);m:tick(1);assert(q.vStop==1 and q.vRestore==true and not m.owner)end)
for _,t in ipairs(tests)do t[2]();print('PASS V2 '..t[1])end
return #tests
